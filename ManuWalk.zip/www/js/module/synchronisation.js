define(["jquery", "./clientService.js", "./cordova.service.js", "./common.js", "./mljdbproc.js", "./mljWalkConstants.js", "./mljDate.js", "./fitnessSource.js"], function($, clientService, networkService, commonModule, mljdbproc, mljdbConstantModule, mljDate, fitnessSourceModule) {

    var synchronisation = {
        sso:null,
        invocationData : {},
        pollingTimer: function(){
            setInterval(synchronisation.updateOAuthToken, oAuthInterval);
            //setInterval(synchronisation.updateStepCountinDashboard, dashboardInterval);
            //synchronisation.startUploadintervaltoSFDC();
            //synchronisation.startSourceInterval();
        },
        updateOAuthToken: function() {
            var deferred = $.Deferred();
            if(networkService.connection()){
                var oAuthReq = clientService.oAuthRequest(), sso = null;
                oAuthReq.done(function(response){
                    if(response !== null && response !== undefined){
                        synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
                        commonModule.updateSSO({
                            instanceUrl: response.instance_url,
                            accessToken: "OAuth " + response.access_token
                        });
                        deferred.resolve(true);
                    }
                    else {
                        console.log('Either network not available or service error');//we have to implement common error function
                        deferred.reject(false);
                    }
                });
                oAuthReq.fail(function(error){
                    console.log(error);
                    deferred.reject(false);
                });
            }
            else commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
            return deferred.promise();
        },
        updateStepCountinDashboard: function(startDatetime, endDatetime) {
		console.log("*******************updateStepCountinDashboard********************"+ new Date());
		console.time('updateStepCountinDashboard');
            var deferred = $.Deferred();
            synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
			
            startDatetime = (typeof startDatetime === "undefined") ? mljDate.getMLJStartDatetime() : mljDate.getMLJStartDatetime(startDatetime);
            endDatetime = (typeof endDatetime === "undefined") ? mljDate.getMLJCurrentDatetime() : mljDate.getMLJEndDatetime(endDatetime);
			var newStartDate = mljDate.getMLJCurrentDate(startDatetime);
            var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("'+ startDatetime +'") AND Datetime("'+ endDatetime +'")';
            $.when(mljdbproc.mljGetDataFromDB(query)).then(function(result){
                if(result !== null && result !== undefined && result.achievedStepCount !== undefined && result.achievedStepCount !== null){
                    var achievedTarget = document.getElementById("achieved-target");
                    var ishomePage = $.mobile.activePage.attr('id');
                    if(ishomePage == "dashboard-page")
                    {
                        if(result.achievedStepCount !== null && result.achievedStepCount<1){
                           result.achievedStepCount = "0"
                        }
						
                        result.achievedStepCount !== null ? $("#achieved-target").shrinkText(result.achievedStepCount) : $("#achieved-target").shrinkText(0);
						
						synchronisation.isDailytargetAchieved(result.achievedStepCount,mljDate.getMLJCurrentDate(startDatetime));
                       
                    }
					$("#sync-loader").hide();
					 deferred.resolve(true);
                }
				else{
					$("#sync-loader").hide();
					deferred.reject(false);
				}
            },function(error){
                if(error !== undefined && error !== null && error.status !== undefined && !error.status){
                    //call common error function
                }
				$("#sync-loader").hide();
                deferred.reject(false);
            });
			console.timeEnd('updateStepCountinDashboard');
            return deferred.promise();
        },
        uploadStepDatatoSFDC: function(lastSyncTime, currentTime) {
		console.log("*******************uploadStepDatatoSFDC********************"+ new Date());
		console.time('uploadStepDatatoSFDC');

			
            var deferred = $.Deferred();
            synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
            var startDatetime = (typeof lastSyncTime === "undefined") ? mljDate.getMLJStartDatetime(mljDate.getMLJCurrentDate(synchronisation.sso.lastUploadSyncToSFDC)) : mljDate.getMLJStartDatetime(mljDate.getMLJCurrentDate(lastSyncTime));
            var endDatetime = (typeof currentTime === "undefined") ? mljDate.getMLJCurrentDatetime() : mljDate.getMLJEndDatetime(currentTime);
			var newSyncDate;
            if(networkService.connection()){
			
			var Maxquery = 'SELECT MAX(lastUpdatedTime) AS newSyncDate FROM ' + mljdbConstantModule.tables[1].name;
			 $.when(mljdbproc.mljGetALLDataFromDB(Maxquery)).then(function(result){
				if(result !== null && result !== undefined && result.length > 0 && result !== null)
				{
					newSyncDate = new Date(result[0].newSyncDate.replace(/-/g,"/"));
				}
				else{
					newSyncDate = new Date();
				}
			 });
			
			
			
                var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount, lastUpdatedTime FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("'+ startDatetime +'") AND Datetime("'+ endDatetime +'") AND source = "'+ synchronisation.sso.source +'" GROUP BY lastUpdatedTime ORDER BY lastUpdatedTime DESC';
                //var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount, lastUpdatedTime FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime LIKE "'+ startDatetime +'%" AND source = "'+ synchronisation.sso.source +'" GROUP BY lastUpdatedTime ORDER BY lastUpdatedTime DESC';
                $.when(mljdbproc.mljGetALLDataFromDB(query)).then(function(result){
                    console.log(result);
                    if(result !== null && result !== undefined && result.length > 0){//&& result[0].achievedStepCount > synchronisation.sso.todayUploadSyncData
                        var uploadObj = {
                            email : synchronisation.sso.email,
                            deviceId : synchronisation.sso.deviceId
                        }, serverSyncDataList = [];
                        var date = null, summaryData = [];
                        var limit = mljDate.getMLJDiffDatetime(startDatetime, endDatetime);
                        var today = new Date, todayms;
                        for(var i = 0; i <= limit; i++){
                            var summary = {};
                            date = mljDate.getMLJCurrentDate(todayms);                   
                            summary.lastUpdatedTime = mljDate.getMLJIsToday(mljDate.getMLJDateFormat(date)) ? new Date() : date;
                            summary.achievedStepCount = filterByDate(date);
                            summaryData.push(summary);
                            todayms = today.setDate(today.getDate()-1);
                        }
                        function filterByDate(date){
                            var count = 0;
                            for(var i = 0; i < result.length; i++){
                                if ('lastUpdatedTime' in result[i] && result[i].lastUpdatedTime.split(' ')[0] === date) {
                                    count += parseInt(result[i].achievedStepCount);
                                }
                            }
                            return count;
                        }                        
                        if (summaryData.length > 5) summaryData.splice(5, summaryData.length-1);
                        for(var i = 0; i < summaryData.length; i++){
                            var stepData = {};
                            var date = typeof summaryData[i].lastUpdatedTime !== "object" ? mljDate.getMLJDateFormat(summaryData[i].lastUpdatedTime):summaryData[i].lastUpdatedTime;
                            stepData.stepCount = parseInt(summaryData[i].achievedStepCount),//mljDate.getMLJIsToday(date) ? parseInt(synchronisation.sso.todayUploadSyncData) + parseInt(summaryData[i].achievedStepCount) : 
                            stepData.mobileAppTimeStamp = date.toISOString(),
                            serverSyncDataList.push(stepData);
                        }
                        uploadObj.serverSyncDataList = serverSyncDataList.reverse();
                        synchronisation.invocationData.url = "/services/apexrest/ServerSync";
                        synchronisation.invocationData.type = "POST";
                        synchronisation.invocationData.data = uploadObj;
                        var request = clientService.cleintRequest(synchronisation.invocationData);
                        request.done(function(response) {
                            if (response.Status.toLowerCase() === "success") {
                                commonModule.updateSSO({
                                    lastUploadSyncToSFDC: newSyncDate,
                                    todayUploadSyncData : serverSyncDataList[serverSyncDataList.length - 1].stepCount
                                });
                                deferred.resolve(true);
                            }
                            else {
                                deferred.reject(false);
                                // call common error function
                            }
                        });
                        request.fail(function(error) {
                            console.log(error.message);
                            deferred.reject(false);
                        });
                    }
                },function(error){
                    if(error !== undefined && error !== null && error.status !== undefined && !error.status){
                        //call common error function
                        deferred.reject(false);
                    }
                });                
            }
            else {
                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
                deferred.reject(false);
            }
			console.timeEnd('uploadStepDatatoSFDC');
            return deferred.promise();
        },
        uploadStepCountinSFDC: function(){
            synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
            var batchNo = (synchronisation.sso.batchNo !== null && synchronisation.sso.batchNo !== undefined) ? synchronisation.sso.batchNo.split(':') : null;
            if((batchNo !== null && new Date().getHours().toString() === batchNo[0] && new Date().getMinutes().toString() === batchNo[1]) || (batchNo !== null && new Date().getHours() === 13 && new Date().getMinutes() === 0)){
                synchronisation.uploadStepDatatoSFDC();
            }
        },
        startUploadintervaltoSFDC: function(){
            synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
            if(synchronisation.sso.batchNo !== null){
                //var uploadSyncIntervals = mljDate.getMLJUserSyncTime(synchronisation.sso.batchNo);
                //if(uploadSyncIntervals !== null && uploadSyncIntervals !== undefined && uploadSyncIntervals.length > 0) {
                //setInterval(synchronisation.uploadStepCountinSFDC, uploadSyncInterval);
                //}
            }
        },
       
       
       startSourceInterval: function(){
       synchronisation.sso = JSON.parse(commonModule.storage.getItem("sso"));
       switch (synchronisation.sso.source) {
       case stepSource[0]://googlefit
	   
       synchronisation.gfitInterval = setInterval(fitnessSourceModule.syncStepwithDB, getSourceInterval);
       break;
       case stepSource[1]://fitbit
	  
       synchronisation.ffitInterval = setInterval(fitnessSourceModule.getDataFromFitbit, getSourceInterval);
       break;
       case stepSource[2]://misfit
	   
       synchronisation.mfitInterval = setInterval(fitnessSourceModule.getDataFromMisfit, getSourceInterval);
       break;
       }
       },
       
        updateDBforLastsevenDays: function(){
            var deferred = $.Deferred();
            networkService.getLastSevenDaysData(function(data){
                                               
                var sso = JSON.parse(commonModule.storage.getItem("sso"));
                var fitnessSourceSelectedDate = mljDate.getMLJStartDatetime(sso.fitnessSourceSelectedDate);
                var endDatetime = (typeof currentTime === "undefined") ? mljDate.getMLJCurrentDatetime() : mljDate.getMLJEndDatetime(currentTime);
                var summaryCountToday = 0;
                var deleteQuery = 'DELETE FROM mljCampaignTransaction WHERE source =? AND lastUpdatedTime BETWEEN  Datetime("'+ fitnessSourceSelectedDate +'") and Datetime("'+ endDatetime +'")';
                                                
                var campaignObj = commonModule.activeCampaignDetails.getItem;
                campaignId = ( campaignObj == null || campaignObj == undefined) ? null :campaignObj.campaignId;
                $.when(mljdbproc.query(deleteQuery,["googlefit"])).then(function(result){
				if(result){
                    var userCountStepHourly,lastUpdatedTime,startDateTime;
                    var query  = "Insert into mljCampaignTransaction (campaignId,achievedStepCount,source,lastUpdatedTime,startDateTime) VALUES(?,?,?,?,?)";
                    for (var i=0; i< data.length; i++)
                    {
                        userCountStepHourly = data[i].value;
                        startDateTime = mljDate.getMLJCurrentDatetime(data[i].startDate);						
                        lastUpdatedTime = mljDate.getMLJCurrentDatetime(data[i].endDate);
						
						if(mljDate.getMLJIsToday(data[i].startDate))
						{
							summaryCountToday = summaryCountToday + data[i].value
						}
						
                        $.when(mljdbproc.query(query, [campaignId,userCountStepHourly,"googlefit",lastUpdatedTime,startDateTime])).then(function(result){
                            console.log("steps synced with local DB"+result);
                            //synchronisation.updateStepCountinDashboard();
                            commonModule.storage.setItem("lastSyncedTime",new Date());
                        });
                    }
					commonModule.updateSSO({
                                dashboardStepCount: summaryCountToday
                    });
				}	
                    deferred.resolve(true);
                     $("#loading-indicator").hide();
                });
            });
        return deferred.promise();
        },
		isDailytargetAchieved:function(target,currdate){
		var daily = JSON.parse(commonModule.storage.getItem("dailyTarget"));
		if((daily !== null) && (daily.date === currdate) && (parseInt(target) >= parseInt(daily.targetSteps)) && (daily.isComplete === false) && (target !== null)){
		navigator.notification.alert(achievedDailytarget,null,"");
		 commonModule.updateLocalstorage({
						date:mljDate.getMLJCurrentDate(),
						isComplete:true
						},"dailyTarget");
			}
		
		/* function alertDismissed() {
        commonModule.updateLocalstorage({
						date:mljDate.getMLJCurrentDate(),
						isComplete:true
						},"dailyTarget");
			} */
			//commonModule.storage.setItem("dailyTarget",JSON.stringify(daily))		
		}
    };
    return synchronisation;
});