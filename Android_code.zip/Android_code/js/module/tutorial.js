define(["jquery", "swiper", "./common.js"], function($, Swiper, commonModule) {
    console.log("Loading tutorial.js");
    var tutorialModule = {
        tutorialObj: {
            tutorialName: "tutorial",
            tutorialId: "#tutorial-carousel",
            url: "tutorials/home-tutorial.html"
        },
        initialize: function() {
            this.homeTutorial(this.tutorialObj);
            $(document).off("click", "#external-link").on("click", "#external-link", function(e) {
                e.preventDefault();
                window.open("http://www1.mhlw.go.jp/topics/kenko21_11/b2.html", '_blank', 'location=no,toolbar=yes,closebuttoncaption= 完了');
            });
            $(document).off("click", ".wellness-lab").on("click", ".wellness-lab", function(e) {
                e.preventDefault();
                window.open("http://wellnesslab.manulife.co.jp/", '_blank', 'location=no,toolbar=yes,closebuttoncaption= 完了');
            });
        },
        initTutorialCarousel: function(options) {
            var opt = options
            $.ajax({
                url: opt.url,
                success: function(data) {
                    $('body').append(data);
                    initCarousel();
                },
                dataType: 'html'
            });

            var initCarousel = function() {
                var tutorial = commonModule.storage.getItem(opt.tutorialName);

                if (tutorial) {
                    $(opt.tutorialId).remove();
                } else {
                    // Initialize swiper when document ready
                    // See https://github.com/nolimits4web/Swiper/tree/master/demos for examples
                    var tutorialCarousel = new Swiper(opt.tutorialId, {
                        direction: "horizontal",
                        loop: false,
                        spaceBetween: 30,

                        // If we need pagination
                        pagination: ".swiper-pagination",

                        // Navigation arrows
                        nextButton: ".swiper-button-next",
                        prevButton: ".swiper-button-prev"
                    });
                    $('body').addClass("overflowH");

                }
            }

        },
        homeTutorial: function(opt) {
            var tut = commonModule.storage.getItem(opt.tutorialName)
            if (!tut) {
                tutorialModule.initTutorialCarousel(opt);
                $(document).on("click", "#register", function(e) {
                    e.stopImmediatePropagation();
                    e.preventDefault();
                    commonModule.storage.setItem(opt.tutorialName, "true");
                    $(opt.tutorialId).remove();
                    //Do important stuff....
                });
            }
        },
        goToPage: function(pageNumber) {
            pageNumber = 0;
        }
    };
    return tutorialModule;
});