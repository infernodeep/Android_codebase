define(["jquery", "./common.js", "./authentication.js", "./walkmap.js", "./donation.js", "./course.js","./mljWalkConstants.js", "./mljdbproc.js", "./mljObjectModel.js", "./cordova.service.js","./pedometer-tutorial.js","./mljDate.js"], function($, commonModule, authModule,walkmapModule, donationModule, courseModule, mljdbConstantModule, mljdbproc, mljObjectModel, cordovaModule,pedoModule,mljDate) {
    console.log("Loading settings.js");
    var settingsModule = {
        nickname: "",
        filename: "",
        userinfo: {},
		dailytarget:null,
        initialize: function() {

            $(document).on("click", "#fitbitLogin", function() {
                authModule.fitbiturl();
                return false;
            });
            $(document).on("click", ".tutorial", function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                var modules = $(this).attr("data-module");
                settingsModule.tutorialInit(modules);
            });
            $(document).on("click", "#updatename", function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
				sso = JSON.parse(commonModule.storage.getItem("sso"));
                settingsModule.userinfo = {
                    oldEmail: sso.email
                };
				 nick = $('#update-nickname').val();
            if (nick!="") {
                settingsModule.userinfo.nickname = $('#update-nickname').val();
				settingsModule.updateUserdetails(settingsModule.userinfo);
            } else {
                navigator.notification.alert(nicknamenotempty,null,"");
                return false;
            }
                
            });
           /*  $(document).on("click", '#profpic', function(e) {
				 cordovaModule.galleryGetPicture(function(uri) {
                settingsModule.profileImage(uri);
				});
            }); */
			 /* $(document).on("change", '#picUpload', function(e) {
                //commonModule.profileImage(e)
				sso = JSON.parse(commonModule.storage.getItem("sso"));
				settingsModule.userinfo.email = sso.email;				
				commonModule.profileImage(e).then(function(result){
                settingsModule.userinfo.fileName = result.name; 
				settingsModule.userinfo.bodyOfAttachment = result.url.split(',')[1];
                $("#profpic").css("background-image", "url(data:image/png;base64," + result.url.split(',')[1] + ")");
                settingsModule.updateUserdetails(settingsModule.userinfo);	
				},function(result){
                           console.log("error")
                }); 
            }); */
			// $(document).on("click", '#profpic', function(e) {
			// 	sso = JSON.parse(commonModule.storage.getItem("sso"));
			// 	settingsModule.userinfo.email = sso.email;	
			// 	cordovaModule.galleryGetPicture(function(uri) {
			// 	settingsModule.userinfo.bodyOfAttachment = uri;	
			// 	$("#profpic").css("background-image", "url(data:image/png;base64," + uri + ")");
			// 	settingsModule.updateUserdetails(settingsModule.userinfo); 
				
              
			// 	});
   //          });


            $(document).on("pagecontainerbeforeshow", function(event, ui) {
                var newPageID = ui.toPage.prop("id");
                switch (newPageID) {
                    case "settings-home":
                        settingsModule.getUserdetails();
                        break;
                    case "settings-change":
                        $("#update-nickname").val(settingsModule.nickname);
                        break;

                }
            });
            $(document).on("pagecontainershow", function(event, ui) {
                var newPageID = ui.toPage.prop("id");

            });

        },
        tutorialInit: function(m) {

            switch (m) {
                case "pedometer":
                    window.localStorage.removeItem(pedoModule.tutorialObj.tutorialName);
                    pedoModule.startTutorial(pedoModule.tutorialObj);
                    break;
                case "donation":
                    window.localStorage.removeItem(donationModule.tutorialObj.tutorialName);
                    donationModule.startTutorial(donationModule.tutorialObj);
                    break;
                case "course":
                    window.localStorage.removeItem(courseModule.tutorialObj.tutorialName);
                    courseModule.startTutorial(courseModule.tutorialObj);
                    break;
                case "walkmap":
                    window.localStorage.removeItem(walkmapModule.tutorialObj.tutorialName);
                    walkmapModule.startTutorial(walkmapModule.tutorialObj);
                    break;
            }
        },
		/* Gets User Information from the local database */
		getUserdetails: function() {
         $("#settings-home #profpic.profpic").click(function(e) {
          sso = JSON.parse(commonModule.storage.getItem("sso"));
          settingsModule.userinfo.oldEmail = sso.email;
		  settingsModule.userinfo.fileName = "filename.jpg";
          cordovaModule.galleryGetPicture(function(uri) {
              settingsModule.userinfo.bodyOfAttachment = uri;
              $("#profpic").css("background-image", "url(data:image/png;base64," + uri + ")");
              settingsModule.updateUserdetails(settingsModule.userinfo);
           });
        });

		var deferred = $.Deferred();
		var userinfo={};
		var profilePic;
		sso = JSON.parse(commonModule.storage.getItem("sso"));
				if(sso){
                    userinfo = {
                        email: sso.email
                    };
		}
		var getQ = 'SELECT * FROM '+ mljdbConstantModule.tables[3].name;
		$.when(mljdbproc.mljGetDataFromDB(getQ)).then(function(result){
                        if(!result){
                            //call common error module
                        }
			 settingsModule.nickname = result.nickname;
			 profilePic = result.bodyOfAttachment;
			$("#profile-name").text(result.nickname);			
				if(profilePic === null || profilePic === "" || result.dailyTarget === "" || result.dailyTarget === null)
				{
				settingsModule.getUserProfileSvc(userinfo).then(function(result){
				deferred.resolve(result);
				});
				}else if(profilePic!= "null"){
				$("#profpic").css("background-image", "url(data:image/png;base64," + profilePic + ")");
				}
				else{
				return false;
				}
				
                    }, function(error) {
                    if (error !== undefined && error !== null && error.status !== undefined && !error.status) {
                        //call common error function
                        deferred.reject(null);
                    }
                });
           return deferred.promise();

        },
		/* Updates User Information to the local database */
		updateUserInfoDB:function(opt){
		console.log(opt)
		var sso = JSON.parse(commonModule.storage.getItem("sso"));
			invocationData = {
					 columns : opt,
                        email : sso.email,
                        tablename : mljdbConstantModule.tables[3].name
                    };
                    $.when(mljdbproc.updateSpecificColumnsToDB(invocationData)).then(function(result){
                        if(result){
                           console.log(result);
                        }
                        else{
                            //call common error fucntion        
                        }
                    }); 
		
		},
        getUserProfileSvc: function(userinfo) {
			var deferred = $.Deferred();
           var sso = JSON.parse(commonModule.storage.getItem("sso"));
            var instUrl = sso.instanceUrl;
            var oauth = sso.accessToken;
            instUrl = instUrl + "/services/apexrest/getUserProfile";
            var request = $.ajax({
                url: instUrl,
                type: "POST",
                contentType: 'application/json',
                headers: {
                    'Authorization': oauth
                },
                data: JSON.stringify(userinfo),
                dataType: "json"
            });
            request.done(function(msg) {
                //  var img = msg.Data[0].bodyOfAttachment;
                if (msg.Status === "SUCCESS") {
                    if (msg.Data[0].bodyOfAttachment !== null) {
                        $("#profpic").css("background-image", "url(data:image/png;base64," + msg.Data[0].bodyOfAttachment + ")");}
						var optCol = {
                            bodyOfAttachment : msg.Data[0].bodyOfAttachment,
							dailyTarget:msg.Data[0].dailytarget,
                            lastUpdatedTime : new Date($.now())
                        };
					if(msg.Data[0].dailytarget !== null){	
					commonModule.updateLocalstorage({
						targetSteps:msg.Data[0].dailytarget,
						date:mljDate.getMLJCurrentDate(),
						isComplete:false
						},"dailyTarget");
					}		
					deferred.resolve(msg.Data[0].dailytarget);		
					settingsModule.updateUserInfoDB(optCol);
                    settingsModule.nickname = msg.Data[0].nickname;
                    $("#profile-name").text(msg.Data[0].nickname);
                } else {
                    console.log(msg.Message.en_US);

                }

            });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
				 deferred.reject(null);
            });
			return deferred.promise();
        },
         profileImage: function(e) {
		 $("#loading-indicator").show();
			sso = JSON.parse(commonModule.storage.getItem("sso"));
            var files = !! event.target.files ? event.target.files : [];
            if (!files.length || !window.FileReader) return;
            if (/^image/.test(files[0].type)) { // only image file
			
			
                var reader = new FileReader(); // instance of the FileReader
                settingsModule.userinfo.oldEmail = sso.email;
                settingsModule.userinfo.fileName = files[0].name;
                //settingsModule.filename = files[0].name; // file name
                reader.readAsDataURL(files[0]); // read the local file

                reader.onloadend = function() { // set image data as background of div
                    // settingsModule.profileImage = this.result.split(',')[1] // base64 URI image
					fixOrientation(this.result, { image: true }, function (fixed, image) {
					settingsModule.userinfo.bodyOfAttachment = fixed.split(',')[1];
                    $("#profpic").css("background-image", "url(data:image/png;base64," + fixed.split(',')[1] + ")");
					$("#loading-indicator").hide();
                    settingsModule.updateUserdetails(settingsModule.userinfo);	
						});
                    
                }
            }

        },
		/* profileImage:function(datauri){
			settingsModule.userinfo.email = sso.email;
			settingsModule.userinfo.fileName = "filename.jpg";
			settingsModule.userinfo.bodyOfAttachment = datauri;
			//$("#profpic img").attr("src","data:image/png;base64,"+datauri);
			$("#profpic").css("background-image", "url(data:image/png;base64," + datauri + ")");
			settingsModule.updateUserdetails(settingsModule.userinfo);
		}, */
        updateUserdetails: function(userinfo) {
            var sso = JSON.parse(commonModule.storage.getItem("sso"));
            var instUrl = sso.instanceUrl;
            var oauth = sso.accessToken,
                instUrl = instUrl + "/services/apexrest/updateProfile";
               
            var request = $.ajax({
                url: instUrl,
                type: "POST",
                contentType: 'application/json',
                headers: {
                    'Authorization': oauth
                },
                data: JSON.stringify(userinfo),
                dataType: "json"
            });
            request.done(function(msg) {
                console.log(msg);
				var optCol = {};
                if (msg.Status === "SUCCESS") {
                    console.log(msg.Message.en_US);
					if(userinfo.nickname){
					optCol.nickname = userinfo.nickname;
					}
					if(userinfo.bodyOfAttachment){
					optCol.bodyOfAttachment = userinfo.bodyOfAttachment
					}
					optCol.lastUpdatedTime = new Date($.now());	
					settingsModule.updateUserInfoDB(optCol);
					if(userinfo.nickname){
                    $(':mobile-pagecontainer').pagecontainer('change', 'settings-home.html', {
                        transition: 'slide'
                    });
					}
                } else {
                    console.log(msg.Message.en_US);

                }

            });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
            });



        },

    };
    return settingsModule;
});