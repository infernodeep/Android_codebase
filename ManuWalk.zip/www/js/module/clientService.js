define(["jquery", "crypto-js", "./cordova.service.js", "./common.js"], function($, cryptoJS, networkService, commonModule) {

    var clientService = {
    	oAuthRequest: function(){
    		var dataEnc = enCryptData;
            var bytes = cryptoJS.AES.decrypt(dataEnc.toString(), 'c58e0e27-d556-474c-ae28-54945ddc815c');
            var data = bytes.toString(cryptoJS.enc.Utf8);
            if(networkService.connection()){
				var request = $.ajax({
	                url: SFDCURL,
	                type: "POST",
	                data: data,
	                dataType: "json",
	                crossDomain: true,
	                headers: {
	                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
	                }                
	            });
	            return request;
        	}
        	else return null;
    	},
    	cleintRequest: function(invocationData) {
    		var sso = JSON.parse(commonModule.storage.getItem("sso"));
    		if(networkService.connection()){
	    		var request = $.ajax({
	                url: sso.instanceUrl + invocationData.url,
	                type: invocationData.type,
	                contentType: 'application/json',
	                headers: {
	                    'Authorization': sso.accessToken
	                },
	                data: (invocationData.type.toLowerCase() !== "get") ? JSON.stringify(invocationData.data):invocationData.data,
	                dataType: "json"
	            });
	            return request;
    		}
    		else return null;
    	},
    	fitbitRequest: function(invocationData) {
    		var sso = JSON.parse(commonModule.storage.getItem("sso"));
    		if(networkService.connection){
	    		var request = $.ajax({
	                url: invocationData.url,
	                type: invocationData.type,
	                contentType: 'application/json',
	                headers: {
	                    'Authorization': sso.fitbitToken
	                },
	                context: {
					    startDate: invocationData.startDate
					},
	                dataType: "json"
	            });
	            return request;
    		}
    		else return null;
    	},
		fitbitSyncRequest: function(invocationData) {
    		var sso = JSON.parse(commonModule.storage.getItem("sso"));
    		if(networkService.connection){
	    		var request = $.ajax({
	                url: invocationData.url,
	                type: invocationData.type,
					async: false,
	                contentType: 'application/json',
	                headers: {
	                    'Authorization': sso.fitbitToken
	                },
	                context: {
					    startDate: invocationData.startDate
					},
	                dataType: "json"
	            });
	            return request;
    		}
    		else return null;
    	}
    };
    return clientService;
});