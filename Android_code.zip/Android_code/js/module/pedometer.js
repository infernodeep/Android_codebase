define(["jquery", "highcharts", "./common.js", "./pedometer-tutorial.js", "./registration.js", "./mljWalkConstants.js", "./mljdbproc.js", "./mljObjectModel.js", "./mljDate.js", "./settings.js"], function($, highcharts, commonModule, pedometerTutorial, registrationModule, mljdbConstantModule, mljdbproc, mljObjectModel, mljDate, settingsModule) {
    console.log("Loading pedometer.js");
    var mobinit = $.Deferred();
    var noOfSteps;

    var pedometerModule = {

        dailyJSON: null,
        userinfo: {},
        date: null,
        initialize: function() {
            // tutorial Initialize
            this.dateformatInit();
            pedometerModule.bind();
            $(document).on("pagecontainerbeforeshow", function(event, ui) {
                var newPageID = ui.toPage.prop("id");
                console.log(ui);
                switch (newPageID) {
                    case "pedometerWalk":
                        pedometerModule.activeTab();
                      
                        break;
                    case "pedometer":
                        settingsModule.getUserdetails().then(function(result) {
                            $('#targetSteps').val(parseInt(result))
                        });
                        pedometerModule.getTargetSteps();
                        pedometerModule.hidePlaceholdertxt();

                        break;
                    case "targetSet":
                        $("#getTarget").text(noOfSteps.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                        break;
                }
            });
            $(document).on("pagebeforechange", function(e, data) {
                if ((data.toPage[0].id == "pedometerWalk") && (data.options.targetDate !== undefined)) {
                           pedometerModule.dashboardDeleteSource();
                   pedometerModule.dailyInit(data.options);

                }
            });
            $(document).on("pagecontainershow", function(event, ui) {
                var newPageID = ui.toPage.prop("id");

                switch (newPageID) {
                    case "pedometerWalk":
                        $("#steps-count-indicator").addClass('day');
                        break;

                }
            });
        },
        bind: function() {
            $(document).off("vclick", "#setTarget").on("vclick", "#setTarget", function(e) {
                e.preventDefault();
                noOfSteps = $('#targetSteps').val();
                var sso = JSON.parse(commonModule.storage.getItem("sso"));
                pedometerModule.userinfo = {
                    "email": sso.email,
                    "target": noOfSteps
                };
                if (noOfSteps != 0) {
                    pedometerModule.updateTargetSteps(pedometerModule.userinfo);
                } else {
                    navigator.notification.alert(entertargetsteps,null,"");
                }

            });
			$(document).off("submit", "form").on("submit", "form", function(e) {
				return false;
			});
            $(document).off("keyup", "#targetSteps").on("keyup", "#targetSteps", function(e) {
                if (this.value.length == 5) {
                    e.preventDefault();
                } else if (this.value.length > 5) {
                    // Maximum exceeded
                    this.value = this.value.slice(0, 5);
                }
            });
            $(document).off("vclick", "#notsetTarget").on("vclick", "#notsetTarget", function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                $(':mobile-pagecontainer').pagecontainer('change', '../dashboard.html', {
                    transition: 'slide'
                });
                commonModule.storage.setItem("setTargetSteps", true);
            })
        },
        hidePlaceholdertxt: function() {
            $('#targetSteps').focus(function() {
                $(this).data('placeholder', $(this).attr('placeholder')).attr('placeholder', '');
            }).blur(function() {
                $(this).attr('placeholder', $(this).data('placeholder'));
            });
        },
        getTargetSteps: function() {
            var getQ = 'SELECT * FROM ' + mljdbConstantModule.tables[3].name;
            $.when(mljdbproc.mljGetDataFromDB(getQ)).then(function(result) {
                if (result.dailyTarget !== null) {
                    $('#targetSteps').val(parseInt(result.dailyTarget));
                }
            });
        },
        updateTargetSteps: function(userinfo) {
            var sso = JSON.parse(commonModule.storage.getItem("sso")),
                instUrl = sso.instanceUrl,
                oauth = sso.accessToken,
                ssoInstUrl = instUrl + "/services/apexrest/SetResetDailyTarget",
                target = {};
            var request = $.ajax({
                url: ssoInstUrl,
                type: "POST",
                contentType: 'application/json',
                headers: {
                    'Authorization': oauth
                },
                data: JSON.stringify(userinfo),
                dataType: "json"
            });
            request.done(function(msg) {
                console.log(msg);
                if (msg.Status === "SUCCESS") {
                    target.dailyTarget = userinfo.target;
                    pedometerModule.updateTargetDB(target);
					//commonModule.updateSSO({dailyTarget : userinfo.target});
					commonModule.updateLocalstorage({
						targetSteps:userinfo.target,
						date:mljDate.getMLJCurrentDate(),
						isComplete:false
						},"dailyTarget");
                    $(':mobile-pagecontainer').pagecontainer('change', 'targetSet.html', {
                        transition: 'slide'
                    });
                    commonModule.storage.setItem("setTargetSteps", true);
                } else {
                    navigator.notification.alert(msg.Message.jp,null,"");
                }

            });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
            });
        },
        updateTargetDB: function(opt) {
            var sso = JSON.parse(commonModule.storage.getItem("sso"));
            invocationData = {
                columns: opt,
                email: sso.email,
                tablename: mljdbConstantModule.tables[3].name
            };
            $.when(mljdbproc.updateSpecificColumnsToDB(invocationData)).then(function(result) {
                if (result) {
                    console.log(result);
                } else {
                    //call common error fucntion        
                }
            });

        },
       
       
       dashboardDeleteSource:function(){
       var deferred = $.Deferred();
       var today = mljDate.getMLJCurrentDate(new Date());
       var sso = JSON.parse(commonModule.storage.getItem("sso"));
       var deleteQ = 'DELETE FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime LIKE "' + today + '%" AND source != "' + sso.source +'"';
       $.when(mljdbproc.query(deleteQ)).then(function(result){
                                             if(result) {
                                             deferred.resolve(true);
                                             }
                                             else deferred.reject(false);
                                             },function(error){
                                             deferred.reject(false);
                                             });
       return deferred.promise();
       
       },
       
        /* Daily Data Initilize */
        dailyInit: function(data) {
            console.log("Daily Init");
            var target = data.targetPg;
            var nextCls = $(".next");
            var prevCls = $(".prev");
            //nextCls.addClass("disabled");
            pedometerModule.enableDisablebtn(target);
            $("#steps-count-indicator").addClass('day').removeClass("week month");
            $(document).off("vclick", ".day .next").on("vclick", ".day .next", function(e) {
                e.preventDefault();
                nextDay();

            });
            $(document).off("vclick", ".day .prev").on("vclick", ".day .prev", function(e) {
                e.preventDefault();
                prevDay();
            });

            $.mobile.document.off("swipeleft", "#pedometerWalk").on("swipeleft", "#pedometerWalk", function() {
                nextDay();
            });
            $.mobile.document.off("swiperight", "#pedometerWalk").on("swiperight", "#pedometerWalk", function() {
                prevDay();
            });


            function nextDay() {
                pedometerModule.dashboardDeleteSource();
                var next = pedometerModule.nextDate();
                if (target <= 0) return false;
                target = target - 1;
                pedometerModule.enableDisablebtn(target);
                var ft = pedometerModule.getPNDate();
                console.log(ft);
                pedometerModule.getDailyData(ft);
            }

            function prevDay() {
                pedometerModule.dashboardDeleteSource();
                var prev = pedometerModule.prevDate();
                console.log("targetPage: " + target);
                if (target > 6) return false;
                target = target + 1;
                pedometerModule.enableDisablebtn(target);
                var ft = pedometerModule.getPNDate();
                pedometerModule.getDailyData(ft);
            }

            DaliyChartInit(data.targetDate);

            function DaliyChartInit(targetDate) {
                console.log("DaliyChartInit");
                var dailyData;
                pedometerModule.currDate = new Date(targetDate).getDate();
                pedometerModule.currMonth = new Date(targetDate).getMonth();
                pedometerModule.currYear = new Date(targetDate).getFullYear();
                var ft = pedometerModule.getPNDate();
				if(ft!== undefined) pedometerModule.getDailyData(ft);
             

            }
        },
        enableDisablebtn: function(target) {
            var nextCls = $(".next");
            var prevCls = $(".prev");
            switch (true) {
                case (target === 0):
                    nextCls.addClass("disabled");
                    prevCls.removeClass("disabled");
                    break;
                case (target > 6):
                    nextCls.removeClass("disabled");
                    prevCls.addClass("disabled");
                    break;
                default:
                    nextCls.removeClass("disabled");
                    prevCls.removeClass("disabled");
            }
        },
        /* Weekly Data Initilize */
        weekInit: function() {
            console.log("Weekly Init");
            var target = 0,
                weekObj = {};
            var nextCls = $(".next");
            var prevCls = $(".prev");
            prevCls.removeClass("disabled");
            nextCls.addClass("disabled");
            $("#steps-count-indicator").removeClass("day month");
            $(document).off("vclick", ".week .next").on("vclick", ".week .next", function(e) {
                e.preventDefault();
                nextWeek();
            });
            $(document).off("vclick", ".week .prev").on("vclick", ".week .prev", function(e) {
                e.preventDefault();
                prevWeek();
            });
            $.mobile.document.off("swipeleft", "#pedometerWalk").on("swipeleft", "#pedometerWalk", function() {
                nextWeek();
            });
            $.mobile.document.off("swiperight", "#pedometerWalk").on("swiperight", "#pedometerWalk", function() {
                prevWeek();
            });

            function nextWeek() {
                var next = pedometerModule.nextWeek();
                if (target <= 0) return false;
                target = target - 1;
                pedometerModule.enableDisablebtn(target);
                var ft = pedometerModule.getWeekDates();
                weekObj.to = ft.to;
                weekObj.from = ft.from;
                weekObj.wm = "week";
                pedometerModule.getActivityData(weekObj);
            }

            function prevWeek() {
                var prev = pedometerModule.prevWeek();
                target = target + 1;
                if (target >= 1) nextCls.removeClass("disabled");

                var ft = pedometerModule.getWeekDates();
                weekObj.to = ft.to;
                weekObj.from = ft.from;
                weekObj.wm = "week";
                pedometerModule.getActivityData(weekObj);
            }

            WeeklyChartInit();

            function WeeklyChartInit() {
                pedometerModule.currDate = new Date().getDate();
                pedometerModule.currMonth = new Date().getMonth();
                pedometerModule.currYear = new Date().getFullYear();
                var ft = pedometerModule.getWeekDates();
                weekObj.to = ft.to;
                weekObj.from = ft.from;
                weekObj.wm = "week";
                pedometerModule.getActivityData(weekObj);


            }
        },

        /* Monthly Data Initilize */
        monthInit: function() {
            console.log("MOnth Init");
            var target = 0,
                monthObj = {};
            var nextCls = $(".next");
            var prevCls = $(".prev");
            prevCls.removeClass("disabled");
            nextCls.addClass("disabled");
            $("#steps-count-indicator").removeClass("day week");
            $(document).off("vclick", ".month .next").on("vclick", ".month .next", function(e) {
                e.preventDefault();
                nextMonth();
            });
            $(document).off("vclick", ".month .prev").on("vclick", ".month .prev", function(e) {
                e.preventDefault();
                prevMonth();
            });
            $.mobile.document.off("swipeleft", "#pedometerWalk").on("swipeleft", "#pedometerWalk", function() {
                nextMonth();
            });
            $.mobile.document.off("swiperight", "#pedometerWalk").on("swiperight", "#pedometerWalk", function() {
                prevMonth();
            });

            function nextMonth() {
                if (target <= 0) return false;
                target = target - 1;
                pedometerModule.MonthenableDisablebtn(target);
                pedometerModule.nextMonth();
                var ft = pedometerModule.getFTMonthDate();
                monthObj.to = ft.to;
                monthObj.from = ft.from;
                monthObj.wm = "month";
                pedometerModule.getActivityData(monthObj);
            }

            function prevMonth() {
                if (target > 5) return false;
                target = target + 1;
                pedometerModule.MonthenableDisablebtn(target);
                pedometerModule.prevMonth();
                var ft = pedometerModule.getFTMonthDate();
                monthObj.to = ft.to;
                monthObj.from = ft.from;
                monthObj.wm = "month";
                pedometerModule.getActivityData(monthObj);
            }
            MonthChartInit();

            function MonthChartInit() {
                pedometerModule.currDate = new Date().getDate();
                pedometerModule.currMonth = new Date().getMonth();
                pedometerModule.currYear = new Date().getFullYear();
                var ft = pedometerModule.getFTMonthDate();
                monthObj.to = ft.to;
                monthObj.from = ft.from;
                monthObj.wm = "month";
                pedometerModule.getActivityData(monthObj);
                //console.log(weektarget);
            }

        },
        MonthenableDisablebtn: function(target) {
            var nextCls = $(".next");
            var prevCls = $(".prev");
            switch (true) {
                case (target === 0):
                    nextCls.addClass("disabled");
                    prevCls.removeClass("disabled");
                    break;
                case (target > 5):
                    nextCls.removeClass("disabled");
                    prevCls.addClass("disabled");
                    break;
                default:
                    nextCls.removeClass("disabled");
                    prevCls.removeClass("disabled");
            }
        },
        /* Get From and To Dates */
        getPNDate: function() {
            var obj = {};
            var ddate = "";
            var current = this.displayDate();
            console.log(current);
            obj.to = current.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            ddate = current.customFormat("#YYYY#/#MM#/#DD#(#DDD#)");
            $("#details p").html(ddate);
            return current;
        },
        /* Get From and To Weeks */
        getWeekDates: function() {
            var obj = {};
            var ddate = "";
            var weekStartDate = this.weekStartDate();
            var weekEndDate = this.weekEndDate();
            obj.to = weekEndDate.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            obj.from = weekStartDate.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            displaydate = weekEndDate.customFormat("#YYYY#/#MM#/#DD#(#DDD#)");
            displaydate += " - ";
            displaydate += weekStartDate.customFormat("#YYYY#/#MM#/#DD#(#DDD#)");
            $("#details p").html(displaydate);
            return obj;
        },
        /* Get From and To Months */
        getFTMonthDate: function() {
            var obj = {};
            var displaydate = "";
            var current = this.monthEndDate();
            var end = this.monthStartDate();
            obj.to = current.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            obj.from = end.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            displaydate = current.customFormat("#YYYY#/#MM#/#DD#(#DDD#)");
            displaydate += " - ";
            displaydate += end.customFormat("#YYYY#/#MM#/#DD#(#DDD#)");
            $("#details p").html(displaydate);
            return obj;

        },
        /* Returns date to display on the page for Daily chart */
        displayDate: function() {
            return new Date(this.currYear, this.currMonth, this.currDate);
        },
        currDate: new Date().getDate(),
        currMonth: new Date().getMonth(),
        currYear: new Date().getFullYear(),
        /* Returns Previous Date */
        prevDate: function() {
            var d = new Date();
            var lastweek = d.setDate(d.getDate() - 7, 1);
            if (new Date(this.currYear, this.currMonth, this.currDate).getDate() === new Date(lastweek).getDate()) {
                return false;
            } else {
                this.currDate--;
                return new Date(this.currYear, this.currMonth, this.currDate);
            }
        },
        /* Returns Next Date */
        nextDate: function() {
            var d = new Date();
            if (this.currDate === d.getDate()) {
                return false;
            } else {
                this.currDate++;
                return new Date(this.currYear, this.currMonth, this.currDate);
            }
        },
        /* Returns first Date of the Month */
        firstDate: function() {
            return new Date(this.currYear, this.currMonth, 1);
        },
        /* Returns last Date of the Month */
        lastDate: function() {
            return new Date(this.currYear, this.currMonth + 1, 0);
        },
        /*Adds a month to the current month */
        nextMonth: function() {
            if (this.currMonth === new Date().getMonth() && this.currYear === new Date().getFullYear()) {
                return false;
            }
            if (this.currMonth != 11) {
                this.currMonth++;
            } else {
                this.currYear++;
                this.currMonth = 0;
            }
        },
        /*Subtracts a month to the current month */
        prevMonth: function() {

            if (this.currMonth !== 0) {
                this.currMonth--;
            } else {
                this.currYear--;
                this.currMonth = 11;
            }
        },
        /*Returns week Start Date */
        weekStartDate: function() {
            return new Date(this.currYear, this.currMonth, this.currDate);
        },
        /*Returns week End Date */
        weekEndDate: function() {
            return new Date(this.currYear, this.currMonth, this.currDate - 6);
        },
        /*Returns week Start Date */
        monthStartDate: function() {
            return new Date(this.currYear, this.currMonth, this.currDate);
        },
        /*Returns week End Date */
        monthEndDate: function() {
            return new Date(this.currYear, this.currMonth, this.currDate - 30);
        },
        /*Subtracts 7 days from the current date */
        prevWeek: function() {
            this.currDate = this.currDate - 7;
        },
        /*Adds 7 days from the current date */
        nextWeek: function() {
            if (this.currDate === new Date().getDate() && this.currMonth === new Date().getMonth()) {
                return false;
            } else {
                this.currDate = this.currDate + 7;
            }
        },
        /* Date Custom format for display on the page */
        dateformatInit: function() {
            Date.prototype.customFormat = function(formatString) {
                var YYYY, YY, MMMM, MMM, MM, M, DDDD, DDD, DD, D, hhhh, hhh, hh, h, mm, m, ss, s, ampm, AMPM, dMod, th;
                YY = ((YYYY = this.getFullYear()) + "").slice(-2);
                MM = (M = this.getMonth() + 1) < 10 ? ('0' + M) : M;
                MMM = (MMMM = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][M - 1]).substring(0, 3);
                DD = (D = this.getDate()) < 10 ? ('0' + D) : D;
                DDD = (DDDD = ["日", "月", "火", "水", "木", "金", "土"][this.getDay()]).substring(0, 3);
                th = (D >= 10 && D <= 20) ? 'th' : ((dMod = D % 10) == 1) ? 'st' : (dMod == 2) ? 'nd' : (dMod == 3) ? 'rd' : 'th';
                formatString = formatString.replace("#YYYY#", YYYY).replace("#YY#", YY).replace("#MMMM#", MMMM).replace("#MMM#", MMM).replace("#MM#", MM).replace("#M#", M).replace("#DDDD#", DDDD).replace("#DDD#", DDD).replace("#DD#", DD).replace("#D#", D).replace("#th#", th);
                h = (hhh = this.getHours());
                if (h === 0) h = 24;
                if (h > 12) h -= 12;
                hh = h < 10 ? ('0' + h) : h;
                hhhh = h < 10 ? ('0' + hhh) : hhh;
                AMPM = (ampm = hhh < 12 ? 'am' : 'pm').toUpperCase();
                mm = (m = this.getMinutes()) < 10 ? ('0' + m) : m;
                ss = (s = this.getSeconds()) < 10 ? ('0' + s) : s;
                return formatString.replace("#hhhh#", hhhh).replace("#hhh#", hhh).replace("#hh#", hh).replace("#h#", h).replace("#mm#", mm).replace("#m#", m).replace("#ss#", ss).replace("#s#", s).replace("#ampm#", ampm).replace("#AMPM#", AMPM);
            };
        },

        /* Get activity Data between From and To dates */
        getActivityData: function(data) {
            sso = JSON.parse(commonModule.storage.getItem("sso"));
            var instUrl = sso.instanceUrl,
                accessToken = sso.accessToken,
                email = sso.email,
                oauth = accessToken,
                ssoinstUrl = instUrl + "/services/apexrest/activityDashBoard";
            var actObj = {};
            actObj.startDateTime = data.to;
            actObj.endDateTime = data.from;
            actObj.email = sso.email;
            var request = $.ajax({
                url: ssoinstUrl,
                type: "POST",
                contentType: 'application/json',
                headers: {
                    'Authorization': oauth
                },
                data: JSON.stringify(actObj),
                dataType: "json"
            });
            request.done(function(msg) {
                if (msg.Status === "SUCCESS") {
                    console.log(msg);
                    pedometerModule.weekMonthData(msg.Data, data)

                } else {
                    console.log(msg);
                }

            });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
            });
        },
        /* Generates data series for the Weekly and Monthly highcharts*/
        weekMonthData: function(obj, dateObj) {
            var newObj = obj.sort(function(a, b) {
                // Turn your strings into dates, and then subtract them
                // to get a value that is either negative, positive, or zero.
                return new Date(a.mobileAppTimeStamp) - new Date(b.mobileAppTimeStamp);
            });
            
            var totalCount = 0;
            var chartObj = {};
            var fromDate = dateObj.from.replace(/T0/g, "T00");
            var toDate = dateObj.to.replace(/T0/g, "T00");
            var dayLen = (dateObj.wm == "month") ? 31 : 7;
            chartObj.pointInterval = 24 * 3600 * 1000;
            chartObj.maxValue = 0;
            chartObj.minValue = 0;
            chartObj.strValue = 0;
            var data = [];
            var dataColors = ['rgb(255, 31, 0)', 'rgb(250, 192, 1)', 'rgb(49, 183, 33)', 'rgb(0, 216, 155)', 'rgb(0, 154, 226)', 'rgb(0, 5, 144)', 'rgb(224, 0, 190)'];
            var series = {};
            var xaxis = {};
            if (obj.length === 0) {
                chartObj.maxValue = 1000;
                chartObj.minValue = chartObj.maxValue / 2;
            }
            var k = 0,
                sfdcDate, curDate,todayDateFormat,curDateString,curDateFormat;
            for (var i = 0; i < dayLen; i++) {
				curDateString = new Date(toDate);
                todayDateFormat = mljDate.getMLJCurrentDate(new Date());
                curDateString = curDateString.setDate(curDateString.getDate() + i);
                curDateFormat = mljDate.getMLJCurrentDate(curDateString);
				sfdcDate = (obj.length > k)? mljDate.getMLJCurrentDate(obj[k].mobileAppTimeStamp) : 0;
				//var stepCount = (typeof obj[i] !="undefined") ? obj[k].stepCount : 0;
				if((typeof obj[k] !="undefined") && (sfdcDate === curDateFormat))
				{
				 totalCount += obj[k].stepCount;
				 maxMinval(obj[k].stepCount);				 
				 series = seriesData(obj[k].mobileAppTimeStamp, obj[k].stepCount);
                 data.push(series);
				 if ((i == 6 && dateObj.wm == "week") || (i == 30 && dateObj.wm == "month")) {
							chart();
				}
                 k++;
				}
				else if((curDateFormat === todayDateFormat) && (i == dayLen-1)){
				pedometerModule.totalDayCount().then(getcurrTotal);
				}
				else
				{
					series = seriesData(curDateString, 0);
					data.push(series);
					if ((i == 6 && dateObj.wm == "week") || (i == 30 && dateObj.wm == "month")) {
							chart();
					}
				}
            }
			
			function getcurrTotal(count){
			totalCount += parseInt(count);
                        maxMinval(parseInt(count));
                        series = seriesData(curDateString, parseInt(count));
                        data.push(series);
                        chart();
			}

            function chart() {
                chartObj.walkman = false;
                chartObj.xaxis = {
                    lineColor: '#00693c',
                    type: 'datetime',
                    minTickInterval: 24 * 3600 * 1000,
                    dateTimeLabelFormats: {
                        day: '%e',
                        week: '%e',
                        month: '%e'
                    },
                    labels: {
                        style: {
                            color: '#00693c',
                            fontSize: '14px'
                        }
                    },
                    tickLength: 5,
                    tickColor: '#00693c',
                    tickWidth: 1,
                    tickPosition: 'inside',
                    //offset: 10
                };
                chartObj.xaxis.min = dateUTC(toDate);
                chartObj.xaxis.max = dateUTC(fromDate);
                $("#chartCount").shrinkText(totalCount);
                chartObj.data = data;
                pedometerModule.chartCreate(chartObj);
            }



            function seriesData(dateObj, steps) {
                return {
                    x: dateUTC(dateObj),
                    y: steps,
                    marker: {
                        fillColor: '#00693c',
                        lineWidth: 0,
                        lineColor: null,
                        fillColor: "#00693c",
                        states: {
                            hover: {
                                fillColor: "#00693c",
                                lineWidth: 0,
                                radius: 0
                            }
                        }
                    }
                }
            }

            function dateUTC(mbldate) {
                var utcObj = {};
                utcObj.year = new Date(mbldate).getFullYear();
                utcObj.month = new Date(mbldate).getMonth();
                utcObj.date = new Date(mbldate).getDate();
                var returnObj = Date.UTC(utcObj.year, utcObj.month, utcObj.date);
                console.log(returnObj);
                return Date.UTC(utcObj.year, utcObj.month, utcObj.date);
            }

            function maxMinval(h) {

                if (h > chartObj.strValue) {
                    chartObj.strValue = h;
                }
                if (chartObj.strValue > 0) {
                    chartObj.maxValue = Math.ceil(chartObj.strValue / 1000) * 1000;
                    chartObj.minValue = chartObj.maxValue / 2;
                } else {
                    chartObj.maxValue = 1000;
                    chartObj.minValue = chartObj.maxValue / 2;
                }
            }


            // console.log(chartObj);
        },
        /* SWIPE */

        /* Generates data series for the Daily highcharts */
        dailyData: function(obj, from) {
            $("#loading-indicator").show();
            var dateObj = {};
            dateObj.year = new Date(from).getFullYear();
            dateObj.month = new Date(from).getMonth();
            dateObj.date = new Date(from).getDate();
            var totalCount = 0;
            var chartObj = {};
            chartObj.pointStart = dateObj;
            chartObj.pointInterval = 3600 * 1000;
            chartObj.maxValue = 0;
            chartObj.minValue = 0;
            chartObj.strValue = 0;
            var data = [];
            var dataColors = ['rgb(255, 31, 0)', 'rgb(250, 192, 1)', 'rgb(49, 183, 33)', 'rgb(0, 216, 155)', 'rgb(0, 154, 226)', 'rgb(0, 5, 144)', 'rgb(224, 0, 190)'];
            var series = {};
            var xaxis = {};
            var hourArr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
            var startDatetime, endDatetime, k;

            var CrHour = (mljDate.getMLJCurrentDate(from) === mljDate.getMLJCurrentDate()) ? new Date().getHours() : 24;

            for (k = 0; k <= hourArr.length && hourArr[k] <= CrHour; k++) {
                if (k === 0) {
                    startDatetime = getFormateDate(0);
                    endDatetime = getFormateEndDate(0);
                } else {
                    startDatetime = getFormateDate(hourArr[k]);
                    endDatetime = getFormateEndDate(hourArr[k]);
                }
                achievedStepCount(startDatetime, endDatetime, k).then(getAchievedSteps);

            }
            chartObj.xaxis = {
                lineColor: '#00693c',
                categories: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
                labels: {
                    style: {
                        color: '#00693c',
                        fontSize: '14px'
                    }
                },
                tickLength: 5,
                tickColor: '#00693c',
                tickWidth: 1,
                tickPosition: 'inside',
                max: 24,
                min: 0,
                tickInterval: 6,
                //offset: 10

            };
            chartObj.walkman = true;
			
			function getAchievedSteps(response){
				maxMinval(response.result);
                series = seriesData(hourArr[response.time], response.result);
                data.push(series);
                if ((hourArr[response.time + 1] > CrHour) || (hourArr[response.time] == 24)) {

                        pedometerModule.totalDayCount(from, from).then(function(count) {
                            $("#chartCount").shrinkText(count);
                        })

                        chartObj.data = data;
                        pedometerModule.chartCreate(chartObj);
                        $("#loading-indicator").hide();
                }
			
			}
			
            function getFormateDate(h) {
                h = (h.toString()).length === 2 ? h : '0' + h;
                m = ((dateObj.month + 1).toString()).length === 2 ? (dateObj.month + 1) : '0' + (dateObj.month + 1);
                d = (dateObj.date.toString()).length === 2 ? dateObj.date : '0' + dateObj.date;
                return dateObj.year + '-' + m + '-' + d + ' ' + h + ':59:59';
            }

            function getFormateEndDate(h) {
                h = (h.toString()).length === 2 ? h : '0' + h;
                m = ((dateObj.month + 1).toString()).length === 2 ? (dateObj.month + 1) : '0' + (dateObj.month + 1);
                d = (dateObj.date.toString()).length === 2 ? dateObj.date : '0' + dateObj.date;
                return dateObj.year + '-' + m + '-' + d + ' ' + h + ':00:00';
            }



            function achievedStepCount(startDatetime, endDatetime, k) {
                var deferred = $.Deferred();
                var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("' + endDatetime + '") AND Datetime("' + startDatetime + '")';
                $.when(mljdbproc.mljGetDataFromDB(query)).then(function(result) {
                    if (result !== null && result !== undefined && result.achievedStepCount !== undefined) {
                        if (result.achievedStepCount !== null) {
                            deferred.resolve({
                                result: result.achievedStepCount,
                                time: k
                            });
                        } else {
                            deferred.resolve({
                                result: 0,
                                time: k
                            });
                        }

                    }

                }, function(error) {
                    if (error !== undefined && error !== null && error.status !== undefined && !error.status) {
                        //call common error function
                        deferred.reject(null);
                    }
                });
                return deferred.promise();
            }

            function maxMinval(h) {
                if (h > chartObj.strValue) {
                    chartObj.strValue = h;
                }
                if (chartObj.strValue > 0) {
                    chartObj.maxValue = Math.ceil(chartObj.strValue / 1000) * 1000;
                    chartObj.minValue = chartObj.maxValue / 2;
                } else {
                    chartObj.maxValue = 1000;
                    chartObj.minValue = chartObj.maxValue / 2;
                }
            }

            function seriesData(t, count) {
                return {
                    x: t,
                    y: count,
                    marker: {
                        fillColor: '#00693c',
                        lineWidth: 0,
                        lineColor: null,
                        states: {
                            hover: {
                                fillColor: "#00693c",
                                lineWidth: 0,
                                radius: 0
                            }
                        }
                    }
                };

            }

        },
        totalDayCount: function(startDatetime, endDatetime) {
            var deferred = $.Deferred();
            startDatetime = (typeof startDatetime === "undefined") ? mljDate.getMLJStartDatetime() : mljDate.getMLJStartDatetime(startDatetime);
            endDatetime = (typeof endDatetime === "undefined") ? mljDate.getMLJCurrentDatetime() : mljDate.getMLJEndDatetime(endDatetime);
            var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("' + startDatetime + '") AND Datetime("' + endDatetime + '")';
            $.when(mljdbproc.mljGetDataFromDB(query)).then(function(result) {
                if (result !== null && result !== undefined && result.achievedStepCount !== undefined) {
                    if (result.achievedStepCount !== null) {
                        deferred.resolve(result.achievedStepCount);
                    } else {
                        deferred.resolve(0);
                    }

                }

            }, function(error) {
                if (error !== undefined && error !== null && error.status !== undefined && !error.status) {
                    //call common error function
                    deferred.reject(null);
                }
            });
            return deferred.promise();


        },

        /* Daily, Weekly and Monthly tabbed buttons */
        activeTab: function() {
            var obj = {};
            $(function() {
                $(document).off("vclick", "#btmnavbar li").on('click', '#btmnavbar li', function(e) {
                    e.preventDefault();
                    $('#btmnavbar li').removeClass('active');
                    var getby = $(this).attr("data-chart");
                    $(this).addClass('active');
                    $("#steps-count-indicator").addClass(getby);
                    switch (getby) {
                        case "week":
                            pedometerModule.weekInit();
                            break;
                        case "month":
                            pedometerModule.monthInit();
                            break;
                        case "day":
							pedometerModule.dashboardDeleteSource();
                            obj.targetPg = 0;
                            obj.targetDate = new Date();
                            pedometerModule.dailyInit(obj);
                            break;
                    }
                    //pedometerModule.chartCreate();
                });
            });
        },
        /*Plots charts on the page for Daily, Weekly and Monthly */
        chartCreate: function(obj) {
            var chart = $('#container').highcharts({
                chart: {
                    type: 'area',
                    renderTo: 'container',
                    spacingBottom: 5,
                    spacingTop: 20,
                    spacingLeft: 20,
                    spacingRight: 20,

                },
                credits: {
                    enabled: false
                },
                title: {
                    text: " "
                },
                xAxis: obj.xaxis,
                yAxis: {
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter: function() {
                            return null;
                        }
                    },
                    minTickInterval: 1000,
                    min: 0,
                    max: obj.maxValue,
                    gridLineColor: '#b2d2c4',
                    gridLineDashStyle: 'Dot',
                    gridLineWidth: '1',
                    plotLines: [{
                        label: {
                            text: obj.maxValue.toString(),
                            align: 'right',
                            x: -10,
                            style: {
                                color: '#00693c',
                                fontSize: '14px'
                            }
                        },
                        value: obj.maxValue,
                        color: '#00693c',
                        dashStyle: 'Solid',
                        width: 1
                    }, {
                        value: obj.minValue,
                        align: 'right',
                        color: '#00693c',
                        dashStyle: 'ShortDot',
                        width: 1
                    }, {
                        label: {
                            text: "0",
                            align: 'right',
                            x: -10,
                            style: {
                                color: '#00693c',
                                fontSize: '14px'
                            }
                        }
                    }]
                },
                plotOptions: {
                    area: {
                        dataLabels: {
                            enabled: true,
                            useHTML: true,
                            align: 'right',
                            x: 0,
                            y: 0,
                            formatter: function() {
                                var first = this.series.data[0],
                                    last = this.series.data[this.series.data.length - 1];
                                if ((this.point.category === last.category && this.point.y === last.y && obj.walkman)) {
                                    return '<div class="walkIcon"><img name="testimg" src="../img/walk.png" width="21" height="35">';
                                }
                                return "";
                            }
                        },
                        marker: {
                            enabled: true,
                            radius: 1
                        },
                        enableMouseTracking: false
                    }
                },
                tooltip: {
                    enabled: false,
                },
                legend: {
                    enabled: false,
                },

                series: [{
                    name: ' ',
                    color: {
                        linearGradient: {
                            x1: 1,
                            y1: 0,
                            x2: 0,
                            y2: 0
                        },
                        stops: [
                            [0, 'rgba(224, 0, 190,0.3)'],
                            [0.16, 'rgba(0, 5, 144,0.3)'],
                            [0.33, 'rgba(0, 154, 226,0.3)'],
                            [0.48, 'rgba(0, 216, 155,0.3)'],
                            [0.64, 'rgba(49, 183, 33,0.3)'],
                            [0.8, 'rgba(250, 192, 1,0.3)'],
                            [1, 'rgba(255, 31, 0,0.3)']
                        ]
                    },
                    lineWidth: 2,
                    data: obj.data,
                    pointInterval: obj.pointInterval // Hourly

                }]

            });
        },

        getDailyData: function(d,data) {
            var startDate = mljDate.getMLJStartDatetime(d);
            var endDate = mljDate.getMLJEndDatetime(d);
            var getQ = "SELECT * FROM " + mljdbConstantModule.tables[1].name + " WHERE lastUpdatedTime BETWEEN Datetime('" + startDate + "') AND Datetime('" + endDate + "')";
            var finalResult;
            $.when(mljdbproc.mljGetALLDataFromDB(getQ)).then(function(result) {
                if (!result) {

                }
                var newObj = result.sort(function(a, b) {
                    // Turn your strings into dates, and then subtract them
                    // to get a value that is either negative, positive, or zero.
                    return new Date(a.startDateTime) - new Date(b.startDateTime);
                });
				if(data !== "cwData") pedometerModule.dailyData(newObj, d);
            });



        },

        getCurrentWeekData: function() {
            var obj = {};
            var weekStartDate = this.weekStartDate();
            var weekEndDate = this.weekEndDate();
            obj.to = weekEndDate.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            obj.from = weekStartDate.customFormat("#YYYY#-#MM#-#DD#T#hhh#:#mm#:#ss#");
            pedometerModule.getPrevActivityData(obj);
        },
        getPrevActivityData: function(data) {

            var self = this;
            sso = JSON.parse(commonModule.storage.getItem("sso"));
            var instUrl = sso.instanceUrl,
                accessToken = sso.accessToken,
                email = sso.email,
                oauth = accessToken,
                ssoinstUrl = instUrl + "/services/apexrest/activityDashBoard";
            var actObj = {};
            actObj.startDateTime = data.to;
            actObj.endDateTime = data.from;
            actObj.email = sso.email;
            var request = $.ajax({
                url: ssoinstUrl,
                type: "POST",
                contentType: 'application/json',
                headers: {
                    'Authorization': oauth
                },
                data: JSON.stringify(actObj),
                dataType: "json"
            });
            request.done(function(msg) {
                if (msg.Status === "SUCCESS") {
                    pedometerModule.updateTransctionData(msg.Data, function() {
                        var current = self.displayDate();
                        pedometerModule.getDailyData(current,"cwData");
                    })

                } else {
                    console.log(msg);
                }

            });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
            });
        },
        updateTransctionData: function(obj, callback) {
            var dbObj = {};
            for (var i = 0; i < obj.length; i++) {
                dbObj.lastUpdatedTime = mljDate.getMLJCurrentDatetime(obj[i].mobileAppTimeStamp);
                dbObj.achievedStepCount = obj[i].stepCount;
                dbupdate(dbObj);
            }

            function dbupdate(dbObj) {
                var registry = mljdbproc.colDefinition(mljdbConstantModule.tables[1].columns);
                var insertQ = 'INSERT INTO ' + mljdbConstantModule.tables[1].name + ' (' + (registry.columnNameColl.join(',')) + ') VALUES (' + (registry.columnValColl.join(',')) + ')';
                registry.columnVal = [{}];
                registry.columnVal[0] = mljdbproc.mljColMapper(mljObjectModel.campaignTransaction, dbObj);
                var invocationData = {
                    tablename: mljdbConstantModule.tables[1].name,
                    seed: registry.columnVal[0],
                    query: insertQ
                };
                $.when(mljdbproc.mljSetDataInDB(invocationData)).then(function(result) {
                    if (!result) {
                        //call common error module
                    }
                });

            }
            callback();
        },


    };
    return pedometerModule;
});