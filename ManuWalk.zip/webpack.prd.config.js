// On production build, strip all console statements. If you are testing this on command line, do not use webpack-dev-server. Use http-server instead (you may need to run 'node install http-server -g')
var webpackStrip = require('strip-loader');
var webpackConfig = require('./webpack.config.js');
webpackConfig.module.loaders.push({
    test: /\.js$/,
    include: webpackConfig.context,
    exclude: /node_modules/, 
    loader: webpackStrip.loader('console.log')
});
module.exports = webpackConfig;