define(["jquery", "./common.js", "./tutorial.js", "./authentication.js", "./cordova.service.js", "./registration.js", "./dashboard.js", "./pedometer.js","./pedometer-tutorial.js", "./walkmap.js", "./donation.js", "./course.js", "./settings.js", "./mljdbproc.js", './synchronisation.js', './fitnessSource.js','./message.js'],
    function ($, commonModule, tutorialModule, authModule, cordovaModule, registrationModule, dashboardModule, pedometerModule,pedometerModuleTutorial, walkmapModule, donationModule, courseModule, settingsModule, mljdbproc, synchronisation, fitnessSourceModule,messageModule) {
        console.log("Loading app.js");
        // Contains methods for initialising the web app and loading them
        // into the Cordova container when the device is ready

        var app = {
            initialize: function () {
               
                this.bindEvents();
                cordovaModule.initialize();
                commonModule.initialize();
                tutorialModule.initialize();
                registrationModule.initialize();
                dashboardModule.initialize();
                pedometerModule.initialize();
				pedometerModuleTutorial.initialize();
                courseModule.initialize();
                walkmapModule.initialize();
                donationModule.initialize();
                settingsModule.initialize();
       
            },

            // Bind any events that are required on startup. Common events
            // are 'load', 'deviceready', 'offline', and 'online'.
            bindEvents: function () {
                document.addEventListener("deviceready", this.onDeviceReady, false);
                document.addEventListener('backbutton', app.backButtonCallback, false);
                document.addEventListener('resume', this.onlineServices, false);
                window.addEventListener('offline', commonModule.checkNetworkConnection);
            },

            // Deviceready Event Handler: The scope of 'this' is the event.
            // In order to call the 'receivedEvent' function, we must
            // explicitly call 'app.receivedEvent(...);'
            onDeviceReady: function () {
                app.receivedEvent("deviceready");
                mljdbproc.initialize();
                authModule.initialize();
                app.getPermissionForLocalNotification();
            },
           getPermissionForLocalNotification:function () {
           cordova.plugins.notification.local.hasPermission(function(granted){
            if(granted == true)
            {
              console.log("gratnted permission")
               messageModule.initialize();
            }
            else
            {
            cordova.plugins.notification.local.registerPermission(function(granted) {
              if(granted == true)
              {
                  console.log("gratnted permission")
                   messageModule.initialize();
              }
              else
              {
                  console.log("app does not have permission")
                 //navigator.notification.alert("Reminder cannot be added because app doesn't have permission");
              }
              });
            }
            })
           },
            backButtonCallback: function () {
                navigator.notification.confirm('Do you want to exit the app?', app.confirmCallback);
            },
            confirmCallback: function (buttonIndex) {
                if (buttonIndex == 1) {
                    navigator.app.exitApp();
                    return true;
                } else {
                    return false;
                }
            },
            // We can load our app now
            receivedEvent: function (id) {
                app.deviceLogged();
                console.log("Received Event: " + id);
				if(device.platform=="iOS"){$('html').addClass("iOS");}else{$('html').addClass("android");}
				/* $(document).one("mobileinit", function () {
				console.log("Hide splashscreen")
						
				}); */
				
				
            },
            deviceLogged: function () {
                var userLogged = window.localStorage.getItem("userLogged");
                synchronisation.gfitInterval="";//add
                synchronisation.ffitInterval="";//add
                synchronisation.mfitInterval="";//add
                if (userLogged) {
                    mljdbproc.activateCampaign();
                    synchronisation.pollingTimer();
                    try{
                        if(cordovaModule.connection()) {
                            synchronisation.updateOAuthToken().then(function(result){
                                donationModule.getCampaign().then(function(result){
                                    app.navigateToDashboard();
                                },function(){
                                    app.navigateToDashboard();
                                });
                            });
                        }
                        else {
                            app.navigateToDashboard();
                        }
                    }
                    catch(e){
                        app.navigateToDashboard();
                    }
                }
                else{
                    $("#memberReg").show("fast");
                    $( document ).on( "mobileinit" , function () {
                        navigator.splashscreen.hide();
						 $.event.special.swipe.horizontalDistanceThreshold = 100;
                    }); 
                }
            },
            navigateToDashboard:function(){
               $.mobile.pageContainer.pagecontainer("change", "dashboard.html");
					$.mobile.pushStateEnabled = false;
            },
            onlineServices: function(){
                var userLogged = window.localStorage.getItem("userLogged");
                if(cordovaModule.connection() && userLogged) {
                    //donationModule.updateDashboardView();
					dashboardModule.dashboardStepsViewInit();
                    //dashboardModule.counter = 1;
                    synchronisation.updateOAuthToken().then(function(result){
                        donationModule.getCampaign();
                        var sso = JSON.parse(commonModule.storage.getItem("sso"));
                        switch (synchronisation.sso.source) {
                            case stepSource[0]://googlefit
                                fitnessSourceModule.syncStepwithDB();
                                synchronisation.uploadStepDatatoSFDC(sso.lastUploadSyncToSFDC, new Date());
                            break;
                            case stepSource[1]://fitbit
                                fitnessSourceModule.getDataFromFitbit(sso.lastUploadSyncToSFDC).then(function(result){
                                    if(result) synchronisation.uploadStepDatatoSFDC(sso.lastUploadSyncToSFDC, new Date());
                                });
                            break;
                            case stepSource[2]://misfit
                                fitnessSourceModule.getDataFromMisfit(sso.lastUploadSyncToSFDC, new Date()).then(function(result){
                                    if(result) synchronisation.uploadStepDatatoSFDC(sso.lastUploadSyncToSFDC, new Date());
                                });
                            break;
                        }
                    });
                }
            }
        };
        app.initialize();
    });
