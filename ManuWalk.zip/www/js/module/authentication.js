define(["jquery", "./common.js", "crypto-js", "./cordova.service.js"], function($, commonModule, cryptoJS, network) {
    console.log("Loading authentication.js");

    var emailAuthenticator = {
        initialize: function() {
            if(network.connection()){
                var dataEnc = enCryptData;
                var bytes = cryptoJS.AES.decrypt(dataEnc.toString(), 'c58e0e27-d556-474c-ae28-54945ddc815c');
                var data = bytes.toString(cryptoJS.enc.Utf8);
                var request = $.ajax({
                    url: SFDCURL,
                    type: "POST",
                    data: data,
                    dataType: "json",
                    crossDomain: true,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                    },
                    success: function(res) {
                        commonModule.updateSSO({instanceUrl : res.instance_url, accessToken : "OAuth " + res.access_token});
                    },
                    error: function(errormessage) {
                        //console.log(errormessage);
                        //navigator.notification.alert("Error while retrieving the access token");
                    }
                });
            }
            else{
                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
            }
        }
    };
    var authenticationModule = {
        initialize: function() {
            setTimeout(commonModule.checkNetworkConnection, networkconnectivity);
            emailAuthenticator.initialize();
        }
    };
    return authenticationModule;
});