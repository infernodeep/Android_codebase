define( [ "jquery","./common.js","./cordova.service.js" ], function($,commonModule,cordovaModule) {
    console.log( "Loading messageModule.js" );
    var messageModule = {
		noteObj:[],
        initialize: function() {
			//$(document).on("pagecontainershow", function (e, ui) {
			//		var currentpage = ui.toPage.prop("id");
					//if ((currentpage === "dashboard-page")) {
					var notify = commonModule.storage.getItem("notify");
						 if(!notify){
                           cordova.plugins.notification.local.hasPermission(function(granted){
                            if(granted == true)
                            {
                            messageModule.msgNotification();
                            }
                            else
                            {                             
                              navigator.notification.alert(notificationError,null,"");
                             
                              //});
                            }
                        })
						}
						//messageModule.msgNotification();
						//}
					/* if(messageModule.noteObj.length > 0){
					cordovaModule.localNotification(messageModule.noteObj);
					}else{
					messageModule.msgNotification();
					} */
						
					//}
			//});
        },
		msgNotification:function(){
	 	var notify = commonModule.storage.getItem("notify");
			//if(!notify){
				var request = $.ajax({
								type: 'GET',
								url: 'data/message.json',
								dataType: 'json'
							});
                    if(device.platform == "iOS")
                           sound = 'file://beep.caf'
                    else
                           sound ='file://sound.mp3'
					request.done(function(res){
					var obj = res.seasonalMessages,schedule_time,reminders=[];
                                 var msgArr = [];
					for (var i = 0; i < obj.length; i++) {
						console.log(obj[i].date)
						var note = {};
                         var modifiedDate =  new Date(obj[i].date)
                         modifiedDate.setHours(0);
                         modifiedDate.setMinutes(0);
                         var newdateFormat = modifiedDate.getTime();
                         schedule_time = new Date(newdateFormat);
						note.id= i+1;
                        note.sound= sound,
						note.title = "ManulifeWalk";
						if(device.platform != "iOS")
						{
							note.message = obj[i].message;
						}
						else{
							note.text = obj[i].message;
						}
						
						note.at = schedule_time;
						if (device.platform != "iOS") {
							note.icon = "file://img/icon.png";
						}
						
                        msgArr.push(note);
						//cordovaModule.localNotification(note);
						//messageModule.noteObj.push(note);
					}
                    cordovaModule.localNotification(msgArr);
					//messageModule.noteObj = reminders;
					
					commonModule.storage.setItem("notify","true");
					});
			// }
		}
		
    };
    return messageModule;
} );
