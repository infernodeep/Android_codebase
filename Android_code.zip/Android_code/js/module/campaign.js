define( [ "jquery" ], function() {
    console.log( "Loading campaign.js" );
    var campaignModule = {
        initialize: function() {
        }
    };
    return campaignModule;
} );
