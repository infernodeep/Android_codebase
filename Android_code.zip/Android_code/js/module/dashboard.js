define( [ "jquery", "./donation.js", "./synchronisation.js", "./mljDate.js","./common.js","./cordova.service.js","./mljWalkConstants.js", "./mljdbproc.js", "./mljObjectModel.js"], function($, donationModule, synchronisation, mljDate,commonModule,networkService,mljdbConstantModule, mljdbproc, mljObjectModel) {
    console.log( "Loading dashboard.js" );
    var targetSetReset;
	var dashboardModule = {
		counter: 0,
		chartDate:null,
        initialize: function() {
			this.pagecreate();
			dashboardModule.bind();
			commonModule.shrinkText();
        },
		pagecreate:function(){
			$(document).on("pagecontainershow", function (e, ui) {
				var currentpage = ui.toPage.prop("id");
                if ((currentpage === "dashboard-page")) {
					 $(document).bind('mobileinit',function(){
						$.mobile.changePage.defaults.changeHash = false;
						$.mobile.hashListeningEnabled = false;
						$.mobile.pushStateEnabled = false;
					});
					setTimeout(function(){
						navigator.splashscreen.hide();					
					},2000);
                         
					dashboardModule.updateDailytargetDate();
                   donationModule.updateDashboardView();
                   dashboardModule.counter = 1;
				   dashboardModule.enableDisablebtn(dashboardModule.counter);
				   dashboardModule.chartDate = new Date();
                }				
			});
       $(document).on("pagecontainerbeforeshow", function (e, ui) {
                      var currentpage = ui.toPage.prop("id");
                      if ((currentpage === "dashboard-page")) {
                      dashboardModule.dashboardDeleteSource();
                      
                      }
                });
		},
		bind : function() {
			$(document).off("click",".courseRecordContainer#course-recorded").on("click",".courseRecordContainer#course-recorded", function(e){
				 e.preventDefault();
				if(!networkService.connection()) {
	                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
	                return;
           		 }
           		 else
           		 {
           		 	  
                     $(':mobile-pagecontainer').pagecontainer('change', 'courseRecording/start-course-recording.html', {
                        transition: 'slide', 
                    }); 
                     commonModule.storage.setItem("mapPage","course")
           		 }
			});

			$(document).off("click",".walkmapContainer#map").on("click",".walkmapContainer#map", function(e){
				 e.preventDefault();
				if(!networkService.connection()) {
	                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
	                return;
           		 }
           		 else
           		 {
           		 	$(':mobile-pagecontainer').pagecontainer('change', 'walkmap/strolling-map.html', {
                        transition: 'slide', 
                    }); 
                    commonModule.storage.setItem("mapPage","walkmap")
           		 }
			});

			$(document).on("click", "#details-button", function(e) {
				e.preventDefault();
				targetSetReset = window.localStorage.getItem("setTargetSteps");
				if(dashboardModule.counter == 0) return false;
				if(targetSetReset && dashboardModule.counter >= 1){
					$(':mobile-pagecontainer').pagecontainer('change', 'pedometer/chart.html', {
                        transition: 'slide',
						targetPg:dashboardModule.counter-1,
						targetDate:dashboardModule.chartDate
                    });
				}
				else{
					$(':mobile-pagecontainer').pagecontainer('change', 'pedometer/pedometer.html', {
                        transition: 'slide'
                    });
				}
			});
			$(document).on("click", ".dashArrow", function(e) {
				var datePrevNext = null;
		 		switch (e.currentTarget.name) {
	                case "left":
	                	dashboardModule.leftData();
						
	                    break;
	                case "right":
						dashboardModule.rightData();
	                    break;
	            }
	            
			});
			
			$.mobile.document.off("swipeleft", "#dashboard-page").on("swipeleft", "#dashboard-page",function(){
                dashboardModule.rightData();
			  });
			  $.mobile.document.off("swiperight", "#dashboard-page").on("swiperight", "#dashboard-page",function(){
              
			   dashboardModule.leftData();
			  });
		},
		leftData:function(){
		var datePrevNext = null;
		if (dashboardModule.counter > 8) return false;
		if(dashboardModule.counter <= 7){
                        dashboardModule.dashboardDeleteSource();
						dashboardModule.counter = dashboardModule.counter + 1;
						dashboardModule.enableDisablebtn(dashboardModule.counter);
	                    datePrevNext = new Date(new Date().setDate(new Date().getDate() - (dashboardModule.counter-1)));
						dashboardModule.chartDate = datePrevNext;
		var dashDate = mljDate.getMLJDashFormat(datePrevNext);
	            datePrevNext !== null ? dashboardModule.getLocalSteps(datePrevNext,datePrevNext) : 0;
	            $('#dash-date').text(dashDate);
		}			
		},
		rightData:function(){
		var datePrevNext = null;
		if (dashboardModule.counter <= 1)return false; 
		if(dashboardModule.counter >= 2){
                        dashboardModule.dashboardDeleteSource();
						dashboardModule.counter = dashboardModule.counter - 1;
						dashboardModule.enableDisablebtn(dashboardModule.counter);
	                    datePrevNext = new Date(new Date().setDate(new Date().getDate() - (dashboardModule.counter-1)));
						dashboardModule.chartDate = datePrevNext;
						var dashDate = mljDate.getMLJDashFormat(datePrevNext);
	            $('#dash-date').text(dashDate);
	            datePrevNext !== null ? dashboardModule.getLocalSteps(datePrevNext,datePrevNext) : 0;		
			}				
		},
		enableDisablebtn: function(target) {
            var nextCls = $('.right-arrow');
            var prevCls = $('.left-arrow');
            switch (true) {
                case (target === 1):
                    nextCls.addClass("disabled");
                    prevCls.removeClass("disabled");
					nextCls.prop('disabled', true);
					prevCls.prop('disabled', false);
                    break;
                case (target > 7):
                    nextCls.removeClass("disabled");
                    prevCls.addClass("disabled");
					nextCls.prop('disabled', false);
					prevCls.prop('disabled', true);
                    break;
                default:
                    nextCls.removeClass("disabled");
                    prevCls.removeClass("disabled");
					nextCls.prop('disabled', false);
					prevCls.prop('disabled', false);
            }
        },
       
       dashboardDeleteSource:function(){
       var deferred = $.Deferred();
       var today = mljDate.getMLJCurrentDate(new Date());
       var sso = JSON.parse(commonModule.storage.getItem("sso"));
       var deleteQ = 'DELETE FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime LIKE "' + today + '%" AND source != "' + sso.source +'"';
       $.when(mljdbproc.query(deleteQ)).then(function(result){
                                             if(result) {
                                             deferred.resolve(true);
                                             }
                                             else deferred.reject(false);
                                             },function(error){
                                             deferred.reject(false);
                                             });
       return deferred.promise();
       
       },
       
		getLocalSteps:function(startDatetime, endDatetime){
		var deferred = $.Deferred(), query;
	            var sso = JSON.parse(commonModule.storage.getItem("sso"));
	            startDatetime = (typeof startDatetime === "undefined") ? mljDate.getMLJStartDatetime() : mljDate.getMLJStartDatetime(startDatetime);
	            endDatetime = (typeof endDatetime === "undefined") ? mljDate.getMLJCurrentDatetime() : mljDate.getMLJEndDatetime(endDatetime);	            
	            query = mljDate.getMLJIsToday(startDatetime) && sso.source !== undefined ? 'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("'+ startDatetime +'") AND Datetime("'+ endDatetime +'") AND source = "'+ sso.source +'"'
	            :'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("'+ startDatetime +'") AND Datetime("'+ endDatetime +'")';
	            $.when(mljdbproc.mljGetDataFromDB(query)).then(function(result){
	                if(result !== null && result !== undefined && result.achievedStepCount !== undefined){                                
	                        result.achievedStepCount !== null ? $("#achieved-target").shrinkText(result.achievedStepCount) : $("#achieved-target").shrinkText(0);
							//synchronisation.isDailytargetAchieved(result.achievedStepCount);
	                        deferred.resolve();
	                    }
	                
	            },function(error){
	                if(error !== undefined && error !== null && error.status !== undefined && !error.status){
	                    //call common error function
	                }
	                deferred.reject();
	            });
	            return deferred.promise();
		},
		dashboardStepsViewInit:function(){
		dashboardModule.dashboardDeleteSource();
			dashboardModule.counter = 1;
			dashboardModule.enableDisablebtn(dashboardModule.counter);
			var date = new Date();
			var dashDate = mljDate.getMLJDashFormat(date);
			$('#dash-date').text(dashDate);
			dashboardModule.getLocalSteps(date,date);
		},
		updateDailytargetDate:function(){
		var daily = JSON.parse(commonModule.storage.getItem("dailyTarget"));
		if(daily !== null && daily.date !== mljDate.getMLJCurrentDate()){
		commonModule.updateLocalstorage({
						date:mljDate.getMLJCurrentDate(),
						isComplete:false
					},"dailyTarget")
		}
		}
	};
    return dashboardModule;
} );
