define(["jquery", "./common.js", "./tutorial.js", "./mljWalkConstants.js", "./mljdbproc.js", "./mljObjectModel.js", "./clientService.js", "./fitnessSource.js", "./mljDate.js", "./synchronisation.js", "./cordova.service.js"], function($, commonModule, tutorialModule, mljdbConstantModule, mljdbproc, mljObjectModel, clientService, fitnessSource, mljDate, synchronisation, networkService) {
    console.log("Loading donation.js");
    var donationModule = {
        tutorialObj: {
            tutorialName: "donationtutorial",
            tutorialId: "#shoes-donation-tutorial",
            url: "../tutorials/shoes-donation-tutorial.html",
        },
        invocationData: {},
        sso: null,
        initialize: function() {
            this.tutorial(this.tutorialObj);
            donationModule.bind();
        },
        bind: function() {
            $(document).on("click", "#participate-button", function(e) {
                e.preventDefault();
                donationModule.registerCampaign(true);
            });
            $(document).off("click", "#donation-facebook-share").on("click", "#donation-facebook-share", function(e) {
                var targetSteps = parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget);
                var contentTobeShared = "Manulife x Moonstar コラボ企画 " + targetSteps + "歩達成！シューズドネーションに応募完了しました。";
                networkService.socialShare("facebook", [contentTobeShared, "donation"], function(data) {
                    console.log("facebook share fixed");
                });
            });
            $(document).off("click", "#donation-twitter-share").on("click", "#donation-twitter-share", function(e) {
                var targetSteps = parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget);
                var contentTobeShared = "[Manulife WALK] Manulife x Moonstar コラボ企画 " + targetSteps + "歩達成！シューズドネーションに応募完了しました。";
                networkService.socialShare("twitter", [contentTobeShared, "donation"], function(data) {
                    console.log("twitter share fixed");
                });
            });
            $(document).off("click", "#donation-line-share").on("click", "#donation-line-share", function(e) {
                var targetSteps = parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget);
                var contentTobeShared = "[Manulife WALK] Manulife x Moonstar コラボ企画 " + targetSteps + "歩達成！シューズドネーションに応募完了しました。";

                window.open("https://line.me/R/msg/text/?" + contentTobeShared + "%0A %0A" + wellnesTabLink, '_system', 'location=no');
            });
            $(document).on("click", "#participate-button-quit-confirm", function(e) {
                e.preventDefault();
                donationModule.registerCampaign(false);
            });
            $(document).on("click", "#shoe-donation", function(e) {
                e.preventDefault();
                var isSkipped = JSON.parse(commonModule.storage.getItem("isSkipped"))
                if (isSkipped) {
                    navigator.notification.alert(skipperuserCampaignMsg, function() {
                        $.mobile.pageContainer.pagecontainer('change', 'registration/registration.html', {
                            reverse: false,
                            changeHash: false,
                            transition: 'slide'
                        });
                        $("#loading-indicator").hide();
                    }, "", "OK");


                } else {
                    donationModule.navigatetoSubscriptionPage('donation');
                }

            });
            $(document).on('pagecontainershow', function(e, ui) {
                donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
                var id = ui.toPage.prop("id");
                if (id === "donating" || id === "donation-page" || id === 'donation-participation-page' || id === 'donation-compliment-page') {
                    donationModule.setDonationview();
                } else if (id === 'donation-share-page' || id === 'donation-quit-page' || id === 'donation-quit-confirm-page' || id === 'donation-abort-page') {
                    donationModule.navigatetoSubscribedPage();
                }
            });
            $(document).on("click", "#participate-button-dashboard", function(e) {
                e.preventDefault();
                $(':mobile-pagecontainer').pagecontainer('change', '../dashboard.html', {
                    transition: 'slide'
                });
            });

            $(document).on("click", "#apply-donation", function(e) {
                donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
                if (donationModule.sso.prizeClaimed === undefined) {
                    donationModule.invocationData.url = "/services/apexrest/claimCampaignPrize";
                    donationModule.invocationData.type = "POST";
                    donationModule.invocationData.data = {
                        email: donationModule.sso.email,
                        campaignId: commonModule.newCampaignDetails.getItem.campaignId,
                        claimPrize: true
                    };
                    var request = clientService.cleintRequest(donationModule.invocationData);
                    request.done(function(response) {
                        if (response.Status.toLowerCase() === "success") {
                            commonModule.updateSSO({
                                prizeClaimed: true
                            });
                            /*$('#apply-donation').prop('disabled', true);
                            $('#apply-donation').addClass('disabled');*/
                            $(':mobile-pagecontainer').pagecontainer('change', 'shoes-donation-social-share.html', {
                                transition: 'slide'
                            });
                        } else if (response.Status.toLowerCase() === "error" && response.Message.en_US === alreadyacquirederror) {
                            commonModule.updateSSO({
                                prizeClaimed: true
                            });
                            navigator.notification.alert(alreadyacquired, function() {
                                $(':mobile-pagecontainer').pagecontainer('change', '../dashboard.html', {
                                    transition: 'slide'
                                });
                            }, "");
                        } else if (response.Status.toLowerCase() === "error" && response.Message.en_US === noshoesavailable) {
                            commonModule.updateSSO({
                                prizeClaimed: false
                            });
                            navigator.notification.alert(noshoesavailable, function() {
                                $(':mobile-pagecontainer').pagecontainer('change', '../dashboard.html', {
                                    transition: 'slide'
                                });
                            }, "");
                        }
                    });
                    request.fail(function(error) {
                        console.log(error.Message);
                    });
                } else {
                    navigator.notification.alert(alreadyacquired, function() {
                        $(':mobile-pagecontainer').pagecontainer('change', '../dashboard.html', {
                            transition: 'slide'
                        });
                    }, "");
                }
            });
            $(document).on("pagecontainerbeforeshow", function(e, ui) {
                var image1 = commonModule.storage.getItem("image");
                var data = {
                    "images": [{
                        image1: image1
                    }]
                }
                var newPageID = ui.toPage.prop("id");
                if ((newPageID == "donation-page-apply")) {
                    var image = document.createElement('img');
                    data.images.forEach(function(obj) {
                        var img = new Image();
                        img.src = obj.image1;
                        img.setAttribute("class", "shoepair");
                        var urlString = 'url(data:image/png;base64,' + obj.image1 + ')';
                        document.getElementById("imgContainer").style.backgroundImage = urlString;
                    });
                } else {
                    //
                }
            });
        },
        tutorial: function(options) {
            // Before Page show event
            $(document).on("pagecontainerbeforeshow", function(e, ui) {
                var newPageID = ui.toPage.prop("id");
                console.log("tutorial: ", newPageID)
                var tut = commonModule.storage.getItem(options.tutorialName);
                if ((newPageID == "donation-page" && !tut)) {
                    donationModule.startTutorial(options);
                } else {
                    //donationModule.removeTutorial(options.tutorialId);
                }
            });
            // On Page show Event
        },
        startTutorial: function(options) {
            tutorialModule.initTutorialCarousel(options);
            $(document).on("click", "#donationok", function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                commonModule.storage.setItem(options.tutorialName, "true");
                donationModule.removeTutorial(options.tutorialId);
            });
        },
        removeTutorial: function(tutorialId) {
            $(tutorialId).remove();
            $('body').removeClass("overflowH");
        },
        updateDashboardView: function() {
            /*if(!networkService.connection()) {
                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
            }*/
            donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            setTimeout(donationModule.showHideNewCampaign, 2000);
            var dashDate = mljDate.getMLJDashFormat();
            $('#dash-date').html(dashDate);
            var timeLapsed = donationModule.minutesElapsed(appLastSyncTime);
            //var oauthLapsed = donationModule.minutesElapsed(oAuthIntervalTime);
            /*var lastsync = mljDate.getMLJCurrentDate(donationModule.sso.lastUploadSyncToSFDC);
            $('#program-end-date').text(lastsync);*/
            // Added flag to ensure fitness source data is read only when app is open or comes in foreground
            if (appResumed) {
                synchronisation.updateOAuthByInterval().then(function(result) {
                    if (result) {
                        fitnessSource.initialize();
                        appResumed = false;
                    }
                });
            } else {
                if (timeLapsed > 5) {
                    synchronisation.updateOAuthByInterval().then(function(result) {
                        if (result) {
                            appLastSyncTime = new Date();
                            sourceUpdate();
                        }
                    });
                } else {
                    synchronisation.updateStepCountinDashboard();
                }
            }



            function sourceUpdate() {
                switch (donationModule.sso.source) {
                    case stepSource[0]: //googlefit
                        fitnessSource.syncStepwithDB();
                        break;
                    case stepSource[1]: //fitbit
                        fitnessSource.getDataFromFitbit(donationModule.sso.lastUploadSyncToSFDC);
                        break;
                    case stepSource[2]: //misfit
                        fitnessSource.getDataFromMisfit(donationModule.sso.lastUploadSyncToSFDC, new Date());
                        break;
                }
            }


            $('.right-arrow').prop('disabled', true);
            $('.right-arrow').addClass('disabled');
            $('.left-arrow').prop('disabled', false);
            $('.left-arrow').removeClass('disabled');
            if (donationModule.sso.lastUploadSyncToSFDC !== undefined) {
                /*var mljDateFormat = mljDate.getMLJStartDatetime(donationModule.sso.lastUploadSyncToSFDC);
                var limit = mljDate.getMLJDiffDatetime(mljDateFormat);
                var today = new Date();
                if(limit > 1) */
                //synchronisation.uploadStepDatatoSFDC(donationModule.sso.lastUploadSyncToSFDC, new Date());
            }
        },
        minutesElapsed: function(time) {
            var timeStart = new Date(time).getTime();
            var timeEnd = new Date().getTime();
            var hourDiff = timeEnd - timeStart; //in ms
            var minDiff = hourDiff / 60 / 1000; //in minutes
            return minDiff;
        },
        getCampaign: function(campaignStatus) {
            var deferred = $.Deferred();
            try {
                donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
                donationModule.invocationData.url = "/services/apexrest/allActiveCampaign";
                donationModule.invocationData.type = "POST";
                donationModule.invocationData.data = {
                    email: donationModule.sso.email
                };
                var request = clientService.cleintRequest(donationModule.invocationData);
                request.done(function(msg) {
                    if (msg.Status.toLowerCase() === "success" && msg.Data.length > 0) {
                        commonModule.newCampaignDetails.setItem = msg.Data[0];
                        commonModule.updateSSO({
                            isNewCampaignExist: true
                        });
                        if (campaignStatus) {
                            donationModule.getCampaignDetails(msg.Data[0].campaignId, campaignStatus).then(function() {
                                deferred.resolve(true);
                            });
                        } else {
                            donationModule.getCampaignDetails(msg.Data[0].campaignId, campaignStatus)
                            deferred.resolve(true);
                        }

                    } else {
                        navigator.notification.alert(msg.Message.en_US, null, "");
                        deferred.reject(false);
                    }
                });
                request.fail(function(error) {
                    if (error !== undefined && error !== null) {
                        error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror, null, "") : navigator.notification.alert(error.responseText, null, "");
                    }
                    deferred.reject(false);
                });
            } catch (e) {
                deferred.reject(false);
            }
            return deferred.promise();
        },
        getCampaignDetails: function(newCampaignId, Cstatus) {
            var deferred = $.Deferred();
            try {
                donationModule.invocationData.url = "/services/apexrest/campaignDetails";
                donationModule.invocationData.type = "POST";
                donationModule.invocationData.data = {
                    campaignID: newCampaignId,
                    email: donationModule.sso.email
                };
                var request = clientService.cleintRequest(donationModule.invocationData);
                request.done(function(msg) {
                    if (msg.Status.toLowerCase() === "success" && msg.Data.length > 0) {
                        msg.Data[0].status = 'D';
                        msg.Data[0].source = donationModule.sso.source;
                        msg.Data[0].lastUpdatedTime = new Date($.now());
                        //check whether the same campaign already exists
                        //if yes update the same mljcampaignmaster table
                        //if no just insert the campaign details to mljcampaignmaster
                        var campaignObj = commonModule.activeCampaignDetails.getItem;
                        campaignId = (campaignObj === null || campaignObj === undefined) ? null : campaignObj.campaignId;
                        if (commonModule.activeCampaignDetails.getItem !== null && msg.Data[0].campaignId === campaignId) {
                            invocationData = {
                                columns: {
                                    campaignFooterNote: msg.Data[0].campaignFooterNote,
                                    totalPrizeDonated: msg.Data[0].totalPrizeDonated,
                                    prizesToBeClaimed: msg.Data[0].prizesToBeClaimed,
                                    campaignTarget: msg.Data[0].campaignTarget,
                                    campaignName: msg.Data[0].campaignName,
                                    campaignDescription: msg.Data[0].campaignDescription,
                                    lastUpdatedTime: new Date($.now())
                                },
                                campaignId: commonModule.activeCampaignDetails.getItem.campaignId,
                                tablename: mljdbConstantModule.tables[0].name
                            };
                            $.when(mljdbproc.updateSpecificColumnsToDB(invocationData)).then(function(result) {
                                if (result) {
                                    mljdbproc.activateCampaign().then(function() {
                                        donationModule.showHideNewCampaign();
                                        deferred.resolve(true);

                                    });
                                }

                            });
                        } else {
                            var registry = mljdbproc.colDefinition(mljdbConstantModule.tables[0].columns);
                            var insertQ = 'INSERT INTO ' + mljdbConstantModule.tables[0].name + ' (' + (registry.columnNameColl.join(',')) + ') VALUES (' + (registry.columnValColl.join(',')) + ')';
                            registry.columnVal = [{}];
                            registry.columnVal[0] = mljdbproc.mljColMapper(mljObjectModel.campaignMaster, msg.Data[0])
                            invocationData = {
                                tablename: mljdbConstantModule.tables[0].name,
                                seed: registry.columnVal[0],
                                query: insertQ
                            };
                            commonModule.newCampaignDetails.setItem = msg.Data[0];
                            $.when(mljdbproc.mljSetDataInDB(invocationData)).then(function(result) {
                                if (!result) {

                                    //call common error module
                                } else {
                                    donationModule.getUserProfile().then(function(result) {
                                        mljdbproc.activateCampaign().then(function() {
                                            donationModule.showHideNewCampaign();
                                            deferred.resolve(true);
                                        });
                                    });
                                }
                            });
                        }
                    } else {
                        navigator.notification.alert(msg.Message.en_US, null, "");
                        deferred.reject(false);
                        //call common error module
                    }
                });
                request.fail(function(error) {
                    if (error !== undefined && error !== null) {
                        error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror, null, "") : navigator.notification.alert(error.responseText, null, "");
                        deferred.reject(false);
                    }
                });
            } catch (e) {
                console.log(e);
            }
            return deferred.promise();
        },
        showHideNewCampaign: function() {
            donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            var activeCampaignDetails = commonModule.activeCampaignDetails.getItem;
            var activePage = $.mobile.activePage.attr('id');
            if ((activeCampaignDetails === null || activeCampaignDetails === undefined) && (commonModule.newCampaignDetails.getItem !== null || donationModule.sso.isNewCampaignExist)) {
                $('#dashboard-options #shoe-donation div span').addClass('new-icon');
                $('#dashboard-options .new-icon').show();
                mljdbproc.getCampaignData(commonModule.newCampaignDetails.getItem.campaignId).then(function(result) {
                    (result !== null && result !== "") ? $('#footer').show().text(result): $('#footer').text();
                }, function() {
                    $('#footer').text();
                });
            } else if (activePage === 'dashboard-page') {
                fitnessSource.getAchievedStepCount().then(function(result) {
                    var inventoryBalance = commonModule.activeCampaignDetails.getItem.inventoryBalance === null ? 0 : parseInt(commonModule.activeCampaignDetails.getItem.inventoryBalance);
                    var achievedStepCount = (result === null || result =="") ? 0 : result;
                    if (commonModule.activeCampaignDetails.getItem.campaignFooterNote !== "" && commonModule.activeCampaignDetails.getItem.campaignFooterNote !== null) $('#footer').show().text(commonModule.activeCampaignDetails.getItem.campaignFooterNote);
                    if (parseInt(achievedStepCount) >= parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget)) {
                        donationModule.sso.congratulationsPopup === undefined ? navigator.notification.alert(congratulations, null, "") : null;
                        commonModule.updateSSO({
                            congratulationsPopup: true
                        });
                        $('#dashboard-options #shoe-donation div span').removeClass('new-icon');
                        $('#dashboard-options #shoe-donation div span').addClass('complete-icon');
                        $('#dashboard-options .complete-icon').show();
                    }
                });
            }
        },
        setDonationview: function() {
            /* commented this, due to campaign opt-in not working */
            $("#targetSteps").shrinkText(commonModule.newCampaignDetails.getItem.campaignTarget);
            //$("#walkedSteps").shrinkText(commonModule.newCampaignDetails.getItem.campaignTarget);

            // $('#targetSteps').text(commonModule.newCampaignDetails.getItem.campaignTarget);
            //$('#walkedSteps').text(commonModule.newCampaignDetails.getItem.campaignTarget);
            $('.subscription-program-name-en').text(commonModule.newCampaignDetails.getItem.campaignName);
        },
        navigatetoSubscribedPage: function() {
            $("#targetSteps").shrinkText(commonModule.newCampaignDetails.getItem.campaignTarget);
            $('.subscription-program-name-en').text(commonModule.newCampaignDetails.getItem.campaignName);
        },
        navigatetoSubscriptionPage: function(path) {
            path = (typeof path !== "undefined") ? path + '/' : '';
            if ((commonModule.activeCampaignDetails.getItem === null || commonModule.activeCampaignDetails.getItem === undefined) && commonModule.newCampaignDetails.getItem !== null) {
                $(':mobile-pagecontainer').pagecontainer('change', path + 'shoes-donation-participate.html', {
                    transition: 'slide'
                });
            } else if (commonModule.activeCampaignDetails.getItem !== null && commonModule.activeCampaignDetails.getItem !== undefined) {
                // both active campaign and new campaign are same
                var achievedStepCount = commonModule.activeCampaignDetails.getItem.achievedStepCount === null ? 0 : parseInt(commonModule.activeCampaignDetails.getItem.achievedStepCount);
                if (achievedStepCount < parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget)) {
                    fitnessSource.checkAchievedStepCount().then(function(result) {
                        if (result) {
                            $(':mobile-pagecontainer').pagecontainer('change', path + 'shoes-donation-steps-screen.html', {
                                transition: 'slide'
                            });
                            $(document).on('pagecontainershow', function(e, ui) {
                                var id = ui.toPage.prop("id");
                                if (id === "donation-page-steps") {
                                    donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
                                    var achievedStepCount = commonModule.activeCampaignDetails.getItem.achievedStepCount === null ? 0 : parseInt(commonModule.activeCampaignDetails.getItem.achievedStepCount);
                                    var goalSteps = parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget) > achievedStepCount ? (parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget) - achievedStepCount) : 0;
                                    goalSteps = (goalSteps > commonModule.activeCampaignDetails.getItem.campaignTarget) ? commonModule.activeCampaignDetails.getItem.campaignTarget : goalSteps;
                                    /*$('.steps-number-stepscreen').text(achievedStepCount);
                                    $('.steps-number-goalSteps').text(goalSteps);*/
                                    var lastsync = mljDate.getMLJCurrentDate(donationModule.sso.lastUploadSyncToSFDC);
                                    $(".steps-number-stepscreen").shrinkText(achievedStepCount);
                                    $(".steps-number-goalSteps").shrinkText(goalSteps);
                                    commonModule.activeCampaignDetails.getItem.totalPrizeDonated !== undefined && commonModule.activeCampaignDetails.getItem.totalPrizeDonated !== null && commonModule.activeCampaignDetails.getItem.totalPrizeDonated !== "" ?
                                        $("#shoes-donated").text(parseInt(commonModule.activeCampaignDetails.getItem.totalPrizeDonated)) : $("#shoes-donated").text(0);
                                    commonModule.activeCampaignDetails.getItem.prizesToBeClaimed !== undefined && commonModule.activeCampaignDetails.getItem.prizesToBeClaimed !== null && commonModule.activeCampaignDetails.getItem.prizesToBeClaimed !== "" ?
                                        $('#shoe-inventory').text(parseInt(commonModule.activeCampaignDetails.getItem.prizesToBeClaimed)) : $('#shoe-inventory').text(0);
                                    $('.program-end-date').text(lastsync.replace(/-/g, "/")); //commonModule.activeCampaignDetails.getItem.campaignEndDate
                                    $('.subscribed-program-name-en').text(commonModule.activeCampaignDetails.getItem.campaignName);
                                }
                            });
                        }
                    });
                } else if (achievedStepCount >= parseInt(commonModule.activeCampaignDetails.getItem.campaignTarget)) {
                    if (donationModule.sso.prizeClaimed === undefined || !(donationModule.sso.prizeClaimed)) {
                        $(':mobile-pagecontainer').pagecontainer('change', path + 'shoes-donation-compliment.html', {
                            transition: 'slide'
                        });
                    } else navigator.notification.alert(alreadyacquired, null, "");
                }
            }
        },
        registerCampaign: function(subscription) {
            if (new Date(commonModule.newCampaignDetails.getItem.campaignEndDate) > new Date($.now())) {
                var invocationData;
                donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
                var data = {
                    "email": donationModule.sso.email,
                    "campaignId": commonModule.newCampaignDetails.getItem.campaignId,
                    "subscribe": subscription
                };
                donationModule.invocationData.url = "/services/apexrest/updateCampaignSubscription";
                donationModule.invocationData.type = "POST";
                donationModule.invocationData.data = data;
                synchronisation.updateOAuthByInterval().then(function(result) {
                    if (result) {
                        var request = clientService.cleintRequest(donationModule.invocationData);
                        request.done(onSuccess);
                        request.fail(onFail);


                    }
                });


                function onSuccess(response) {
                    if (response.Status.toLowerCase() === "success") {
                        //update the local DB

                        donationModule.updateCampaignStatus(subscription).then(function(result) {
                            if (result && subscription) {
                               
                            commonModule.updateSSO({
                                campaignRegisterDate: new Date()

                            });
                                $(':mobile-pagecontainer').pagecontainer('change', 'shoes-donation-participated.html', {
                                    transition: 'slide'
                                });
                            } else if (result && !subscription) {
                                $(':mobile-pagecontainer').pagecontainer('change', 'shoes-donation-aborted-participation.html', {
                                    transition: 'slide'
                                });
                            }
                        });
                    } else if (response.Status.toLowerCase() === "error" && response.Message['en_US'].toLowerCase() === 'you have already opted for this campaign ') {
                        navigator.notification.alert(response.Message.en_US, function() {
                            donationModule.updateCampaignStatus(subscription);
                        }, "");
                    } else {
                        navigator.notification.alert(response.Message['en_US']);
                        //call common error fucntion
                    }
                }

                function onFail(error) {
                    if (error !== undefined && error !== null) {
                        error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror, null, "") : navigator.notification.alert(error.responseText, null, "");
                    }
                }
            } else {
                navigator.notification.alert(campaignExpired, null, "");
            }
        },
        updateCampaignStatus: function(subscription) {
            var deferred = $.Deferred();
            var campaignId = subscription ? commonModule.newCampaignDetails.getItem.campaignId : commonModule.activeCampaignDetails.getItem.campaignId;
            var invocationData = {
                columns: {
                    activeCampaignId: subscription ? campaignId : null,
                    lastUpdatedTime: new Date($.now())
                },
                email: donationModule.sso.email,
                tablename: mljdbConstantModule.tables[3].name
            };
            $.when(mljdbproc.updateSpecificColumnsToDB(invocationData)).then(function(result) {
                if (result) {
                    invocationData = {
                        columns: {
                            status: subscription ? 'A' : 'D'
                        },
                        campaignId: campaignId,
                        tablename: mljdbConstantModule.tables[0].name
                    };
                    $.when(mljdbproc.updateSpecificColumnsToDB(invocationData)).then(function(result) {
                        if (result) {
                            if (subscription) {
                                mljdbproc.activateCampaign();
                            } else commonModule.activeCampaignDetails.setItem = null;
                            deferred.resolve(true);
                        } else {
                            deferred.reject(false);
                            //call common error fucntion        
                        }
                    });
                } else {
                    deferred.reject(false);
                    //call common error fucntion        
                }
            });
            return deferred.promise();
        },
        getUserProfile: function(validate) {
            var deferred = $.Deferred();
            donationModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            var data = {
                "email": donationModule.sso.email
            };
            donationModule.invocationData.url = "/services/apexrest/getUserProfile";
            donationModule.invocationData.type = "POST";
            donationModule.invocationData.data = data;
            var request = clientService.cleintRequest(donationModule.invocationData);
            synchronisation.updateOAuthToken().then(function(result) {
                request.done(function(response) {
                    if (response.Status !== null && response.Status.toLowerCase() === "success" && response.Data.length > 0) {
                        if (validate === undefined) {
                            if (response.Data[0].CampaignId !== null && response.Data[0].CampaignId !== undefined) {
                                donationModule.updateCampaignStatus(true).then(function(result) {
                                    deferred.resolve(true);
                                });
                            }
                        } else {
                            deferred.resolve(response.Data[0]);
                        }
                    } else deferred.resolve(false);
                });
                request.fail(function(error) {
                    if (error !== undefined && error !== null) {
                        error.responseText = (error.responseText === '' || error.responseText === null || error.responseText === undefined) ? navigator.notification.alert(unknownerror, null, "") : navigator.notification.alert(error.responseText, null, "");
                    }
                    deferred.reject(false);
                });
            });
            return deferred.promise();
        }
    };
    return donationModule;
});