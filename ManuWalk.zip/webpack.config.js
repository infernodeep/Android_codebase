var path = require( "path" );
var ExtractTextPlugin = require( "extract-text-webpack-plugin" );
var webpack = require( "webpack" );
var pathTo = {
    javaScript: path.resolve( "www/js" ),
    styleSheet: path.resolve( "www/css" ),
    nodeModules: path.resolve( "node_modules" )
};

module.exports = {

    // The base directory (absolute path!) for resolving the entry option
    context: pathTo.javaScript,

    // The entry point for the bundle. You can pass a string, array of
    // strings, or an object (for creating multiple bundles).
    entry: {
        app: [
            "./module/cordova.service.js",
            "./module/app.js",
            "./module/common.js",
            "./module/tutorial.js",
            "./module/registration.js",
            "./module/authentication.js",
			"./module/pedometer.js",
			"./module/pedometer-tutorial.js",
            "./module/settings.js",
            "./module/dashboard.js",
            "./module/campaign.js",
            "./module/reward.js",
            "./module/course.js",
            "./module/mljdbproc.js",
            "./module/mljWalkConstants.js",
            "./module/mljObjectModel.js",
            "./module/clientService.js",
            "./module/synchronisation.js",
            "./module/fitnessSource.js",
            "./module/mljDate.js",
            "./module/message.js"
        ],
        lib: [
            //"jquery",
            //"jquery.mobile",
            //"ratchet",
			//"./lib/jquery/jquery.js",
			//"./lib/jquery-mobile/jquery.mobile.js",
            "swiper",
			"hellojs",
			"highcharts",
            "node-misfit",
			"fix-orientation"
        ]
    },

    // Resolve the vendor libraries using aliases so they are easy to work
    // with in the code
    resolve: {

        // The following folders, if present, will be used for resolving
        // module names
        moduleDirectories: [
            "node_modules"
        ],

        // Create aliases for modules which you would like to refer using
        // shorthand
        alias: {

            //TODO: An alias should not be required for this
			"webfonts.css": path.join( pathTo.styleSheet, "module/webfonts.css" ),
            "app.css": path.join( pathTo.styleSheet, "module/app.css" ),
            "registration.css": path.join( pathTo.styleSheet, "module/registration.css" ),
            "dashboard.css": path.join( pathTo.styleSheet, "module/dashboard.css" ),
            "pedometer.css": path.join( pathTo.styleSheet, "module/pedometer.css" ),
            "donation.css": path.join( pathTo.styleSheet, "module/donation.css" ),
            "walkmap.css": path.join( pathTo.styleSheet, "module/walkmap.css" ),
            "course.css": path.join( pathTo.styleSheet, "module/course.css" ),
			"settings.css": path.join( pathTo.styleSheet, "module/settings.css" ),
            

            // Reference to jQuery Mobile styles and JS
            "jquery.mobile.css": path.join( pathTo.nodeModules, "jquery-mobile/dist/jquery.mobile.structure.min.css" ),
            
            // Reference to swiper styles
            "swiper.css": path.join( pathTo.nodeModules, "swiper/dist/css/swiper.css" ),
        }
    },

     externals: {
        // Cordova.js is special because it is different for different
        // platforms. We just have a placeholder for cordova.js in index.html,
        // but the actual module is available inside the platform specific
        // www folder.However, we would need to require('cordova') to access
        // plugin functionality.Hence, make it available as an external.
        // See http://webpack.github.io/docs/configuration.html#externals and
        // http://stackoverflow.com/questions/23305599/webpack-provideplugin-vs-externals
        // for details.
        cordova: "cordova",
        jquery: "jQuery"
    },

    // Set output path to the 'min' folder from where the gulp task can pick
    // up the bundled files
    output: {
        path: pathTo.javaScript,
        filename: "[name].bundle.js",
        sourceMapFilename: "[file].map"
    },

    // Setup dev-server defaults
    devServer: {
        contentBase: "www"
    },

    // Enhance debugging with source maps; make sure you run 'webpack -d'
    // to build with devtools support; otherwise, source maps are not created
    devTool: "#source-map",

    // Module loaders
    module: {

        preLoaders: [

            //     // https://github.com/webpack/jshint-loader
            //     {
            //         test: /\.js$/,
            //         include: pathTo.javaScript,
            //         exclude: /node_modules/,
            //         loader: 'jshint-loader'
            //     },
            //     // https://github.com/MoOx/eslint-loader
            //     {
            //         test: /\.js$/,
            //         include: pathTo.javaScript,
            //         exclude: /node_modules/,
            //         loader: 'eslint-loader'
            //     },
            // https://github.com/unindented/jscs-loader
            {
                test: /\.js$/,
                include: pathTo.javaScript,
                exclude: /node_modules/,
                loader: "jscs-loader"
            }
        ],
        loaders: [

            // https://github.com/mistadikay/strict-loader
            {
                test: /\.js$/,
                include: pathTo.javaScript,
                exclude: /node_modules/,
                loader: "strict"
            },

            // https://github.com/hyungjs/csslint-loader
            // {
            //     css: /\.css$/,
            //     include: pathTo.styleSheet,
            //     loader: 'style?css!csslint'
            // },
            {
                test: /\.css$/,
                //loader: "style-loader!css-loader"
				loader: ExtractTextPlugin.extract( "style-loader", "css-loader" )
            },
            {
                test: /\.(png|jpg|gif|svg|ttf|woff|eot|otf)$/,
                loader: "url-loader?limit=100000"
            },

            // {
            //     test: /[\/\\]node_modules[\/\\]jquery.mobile\.js$/,
            //     loader: "imports?$=jquery"
            // }
        ]
    },

    plugins: [
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            "window.jQuery": "jquery"
        }),
        new ExtractTextPlugin("[name].bundle.css")
    ],

    // Configure eslint. Install eslint-config-defaults
    // (https://www.npmjs.com/package/eslint-config-defaults) for some
    // widely used eslint configurations.
    eslint: {
        configFile: path.resolve( ".eslintrc" ),
        emitWarning: false,
        emitError: false,
        failOnWarning: false,
        failOnError: false
    },

    // Configure JavaScript Code Style checker
    jscs: {

        // JSCS errors are displayed by default as warnings.
        // Set `emitErrors` to `true` to display them as errors.
        emitErrors: true,

        // JSCS errors do not interrupt the compilation.
        // Set `failOnHint` to `true` if you want any file with
        // JSCS errors to fail.
        failOnHint: false
    }
};
