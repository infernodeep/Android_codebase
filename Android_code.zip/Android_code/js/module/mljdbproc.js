define(["jquery", "./common.js", "./mljWalkConstants.js", "./mljObjectModel.js"], function($, commonModule, mljdbConstantModule, mljObjectModel) {
var createTBLModule = {
    
    initialize: function() {
        this.db = commonModule.mljDBInit();
        var tables = mljdbConstantModule.tables;
        this.populateDB(tables);
    },
    colDefinition: function(column){
        var type;
        var registry = {
            columns : [],
            columnNameColl : [],
            columnValColl : []
        };
        $.each(column, function(index, obj) {
            type = (column[index].type !== '')? (' ' + column[index].type) : '';
            registry.columns.push('' + column[index].name + type);
            registry.columnNameColl.push(column[index].name);
            registry.columnValColl.push('?');
        });
        return registry;
    },
    mljColMapper: function(source, dest){
        for (var attr in dest) {
            if(source.hasOwnProperty(attr)){
                source[attr] = dest[attr];
            }
        }
        return source;
    },
    query: function(query, bindings) {
        try{
            this.db = commonModule.mljDBInit();
            if(this.db !== null && this.db !== undefined){
                var deferred = $.Deferred();
                bindings = (typeof bindings !== "undefined" ? bindings : []);
                this.db.transaction(function(transaction) {
                    console.log("query: " +JSON.stringify(query));
                    transaction.executeSql(query, bindings, onSuccess, onFailure);
                });
                var onFailure = function(transaction, error) {
                    deferred.reject({error:error,status:false});
                    console.log("SQL Error: "+ error.code);
                };
                var onSuccess = function(transaction, result) {
                    console.log("SQL Result: " +result);
                    deferred.resolve(result);
                };
                return deferred.promise();
            }
            else throw new Error("SQL Error: DB is not initialized");
        }
        catch(e){
            //call common exception function
        }
    },
    //create table and insert some record
    populateDB: function(tables) {
        if(tables !== null && tables !== undefined){
             $.each(tables, function(index, obj) {
                var query = 'SELECT name FROM sqlite_master WHERE type="table" AND name="'+obj.name+'"';
                $.when(createTBLModule.query(query)).then(function(result){
                    if(result.rows.length === 0){
                        var registry = createTBLModule.colDefinition(tables[index].columns);
                        query = 'CREATE TABLE ' + tables[index].name + ' (' + (registry.columns.join(',')) + ')';//CREATE TABLE IF NOT EXISTS
                        createTBLModule.query(query);
                    }
                });
             });
        }
    },
    mljSetDataInDB: function(invocationData){
        try{
            var deferred = $.Deferred();
            var seed = [];
            $.each(invocationData.seed,function(key, value){
                seed.push(value);
            });
            if (seed !== null && seed !== undefined){
                $.when(createTBLModule.query(invocationData.query, seed)).then(function(result){
                if(result !== null && result !== undefined && result.rowsAffected !== null && result.rowsAffected !== undefined && result.rowsAffected > 0){
                    deferred.resolve(true);
                }
                else{
                    deferred.reject(false);
                }
                },function(error){
                    deferred.reject(error);   
                });
            }
            return deferred.promise();
        }
        catch(e) {
            //call common exception function
        }
    },
    mljGetDataFromDB: function(query){
        try{
            var deferred = $.Deferred();
            $.when(createTBLModule.query(query)).then(function(result){
                if(result !== null && result !== undefined && result.rows.length > 0){
                    for(var i=0; i<result.rows.length; i++){
                        var row = result.rows.item(i);
                        deferred.resolve(row);
                    }
                }
                else{
                    deferred.reject(null);
                }
            },function(error) {
                //call common exception function
                deferred.reject(error);
            });
            return deferred.promise();
        }
        catch(e) {
            console.log(e);
            //call common exception function
        }
    },
	mljGetALLDataFromDB: function(query){
        try{
            var deferred = $.Deferred();
			var row = [];
            $.when(createTBLModule.query(query)).then(function(result){
                if(result !== null && result !== undefined && result.rows.length > 0){
					//$.each(result.rows,function(index){
                      for(var i=0; i<result.rows.length; i++){    
                        row.push(result.rows.item(i));
                        }
					deferred.resolve(row);
                }
                else if(result.rows.length === 0){
				deferred.resolve(row);  
                }
				else
				{
				deferred.reject(null);
				}
            },function(error) {
                //call common exception function
                deferred.reject(error);
            });
            return deferred.promise(row);
        }
        catch(e) {
            console.log(e);
            //call common exception function
        }
    },
    /*
    sample updateObj = {
                        columns : {
                            'ColumnName' : column value
                        },
                        property name for where clause : value,
                        tablename : table name which you need to update,
                    };
    */
    updateSpecificColumnsToDB : function(invocationData) {
        var data = [], attrbs = [];
            row = null,
            deferred = $.Deferred(),
            updateDataString = '',
            query = '';
        try{
            $.each(invocationData.columns,function(key,value){
                data.push(key +"='" + value +"'");
            });
            for(var attr in invocationData){
                attrbs.push(attr);
            }
            if(attrbs.length !== 0 && data.length !== 0){
                query = 'UPDATE ' + invocationData.tablename +
                ' SET ' + data.join(',') +
                ' WHERE '+attrbs[1]+'="' + invocationData[attrbs[1]]+'"';
                $.when(createTBLModule.query(query)).then(function(result){
                    deferred.resolve(true);
                }, function (error) {
                    //call common exception function
                    deferred.reject(false);
                });
            }
            else deferred.reject(false);
            return deferred.promise();
        }
        catch(e){
            //call common exception function
        }
    },
    activateCampaign:function(){
        var deferred = $.Deferred(),
        query = 'SELECT * FROM '+ mljdbConstantModule.tables[0].name +' WHERE status = "A"';
        $.when(createTBLModule.mljGetDataFromDB(query)).then(function(result){
            if(result !== null && result !== undefined && result.campaignId !== undefined && result.campaignId !== null){
                commonModule.activeCampaignDetails.setItem = result;
                deferred.resolve();
            }
            else{
                commonModule.activeCampaignDetails.setItem = null;
                deferred.resolve();
            }
        },function(error){
            if(error !== undefined && error !== null && error.status !== undefined && !error.status){
                commonModule.activeCampaignDetails.setItem = null;
                deferred.reject();
                //call common error function
            }
        });
        return deferred.promise();
    },
    getCampaignData: function(campaignId){
        var deferred = $.Deferred(),
        query = 'SELECT campaignFooterNote FROM '+ mljdbConstantModule.tables[0].name +' WHERE campaignId = "'+ campaignId +'"';
        $.when(createTBLModule.mljGetDataFromDB(query)).then(function(result){
            if(result !== null && result !== undefined && result.campaignFooterNote !== undefined && result.campaignFooterNote !== null){
                deferred.resolve(result.campaignFooterNote);
            }
            else{
                deferred.resolve(null);
            }
        },function(error){
            if(error !== undefined && error !== null && error.status !== undefined && !error.status){
                deferred.reject();
                //call common error function
            }
        });
        return deferred.promise();
    } 
 };
return createTBLModule;
});